﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Dto
{
    public class ConsultationDto
    {
        private int id;
        private string date;
        private string temperature;
        private string tension;
        private string motif;
        private string poids;

        //Attributs navigationnels
        //one to many
        private Medecin medecin;
        private Patient patient;

        public int Id { get => id; set => id = value; }
        public string Date { get => date; set => date = value; }
        public Medecin Medecin { get => medecin; set => medecin = value; }
        public Patient Patient { get => patient; set => patient = value; }

       
    }
}
