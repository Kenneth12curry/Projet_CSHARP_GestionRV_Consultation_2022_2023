﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Dto
{
    public enum RolePatient
    {
        Patient
    }

    public class PatientDto
    {
        private int id;
        private string nom;
        private string prenom;
        private string code;
        private string email;
        private string tel;
        private RolePatient role;
       

        public PatientDto()
        {
           role=RolePatient.Patient;
           
        }

        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        public string Code { get => code; set => code = value; }
        public RolePatient Role1 { get => role; set => role = value; }
        public string Email { get => email; set => email = value; }
        public string Tel { get => tel; set => tel = value; }

        public override string ToString()
        {
            return Nom+" "+Prenom;
        }

        public Patient toPatient()
        {
            return new Patient()
            {
                Id= id,
                Nom= nom,
                Prenom= prenom,
                Code= code,
               

            };
        }
    }
}
