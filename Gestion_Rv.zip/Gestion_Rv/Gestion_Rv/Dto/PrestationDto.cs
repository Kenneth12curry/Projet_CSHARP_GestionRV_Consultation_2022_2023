﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Dto
{
    public class PrestationDto
    {
        private int id;
        private string date;
        private string type;
        //Attributs navigationnels
        //one to many
        private Patient patient;
        private RP rp;

        public int Id { get => id; set => id = value; }
        public string Date { get => date; set => date = value; }
        public string Type { get => type; set => type = value; }
        public Patient Patient { get => patient; set => patient = value; }
        public RP Rp { get => rp; set => rp = value; }

        public Prestation toPrestation()
        {
            return new Prestation()
            {
                Id= id,
                Date= date,
                Type= type,
                Patient= patient,
                Rp= rp

            };
        }
    }
}
