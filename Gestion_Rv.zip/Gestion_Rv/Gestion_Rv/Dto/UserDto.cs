﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Dto
{
    public class UserDto
    {
        private int id;
        private string nom;
        private string prenom;
        private Role role;

        public int Id { get => id; set => id = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        public Role Role { get => role; set => role = value; }

        public User toUser()
        {
            return new User()
            {
                Id = id,
                Nom = nom,
                Prenom = prenom,
                Role= role

            };
        }
    }
}
