﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public class AntecedentsMedicaux
    {
        private string libelle;
        //OneToMany
        private Patient patient;
        public string Libelle { get => libelle; set => libelle = value; }
        public Patient Patient { get => patient; set => patient = value; }

    }
}
