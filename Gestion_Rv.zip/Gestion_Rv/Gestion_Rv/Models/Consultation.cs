﻿using Gestion_Rv.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public class Consultation 
    {
        private int id;
        private string date;
        private string temperature;
        private string tension;
        private string motif;
        private string poids;

        //Attributs navigationnels
        //one to many
        private Medecin medecin;
        private Patient patient;
        private RendezVous rdv;
        private Ordonnance ordonnance;

        //public string Mededin { get => mededin; set => mededin = value; }
        public int Id { get => id; set => id = value; }
        public string Date { get => date; set => date = value; }
        public string Temperature { get => temperature; set => temperature = value; }
        public string Tension { get => tension; set => tension = value; }
        public string Motif { get => motif; set => motif = value; }
        public string Poids { get => poids; set => poids = value; }
        public Patient Patient { get => patient; set => patient = value; }
        public Medecin Medecin { get => medecin; set => medecin = value; }
        public RendezVous Rdv { get => rdv; set => rdv = value; }
    }
}
