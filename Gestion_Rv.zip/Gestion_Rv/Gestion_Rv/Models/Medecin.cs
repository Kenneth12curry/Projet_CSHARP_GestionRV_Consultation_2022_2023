﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public enum TypeM
    {
        Généraliste, Spécialiste
    }
    public class Medecin:User
    {
        protected TypeM type;
        //Attributs navigationnels
        //ManyToOne
        //private List<RendezVous> rv;
        private List<Consultation> consultations;

        public Medecin()
        {
            role = Role.Medecin;
            type = TypeM.Généraliste;
            
        }

        //public List<RendezVous> Rv { get => rv; set => rv = value; }
        public TypeM Type { get => type; set => type = value; }

        public override string ToString()
        {
            return Prenom + " " + Nom;
        }
    }
}
