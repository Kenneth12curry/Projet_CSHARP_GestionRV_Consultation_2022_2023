﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public class Medicament
    {
        private int id;
        private string code;
        private string nom;
        private string posologie;
        //attributs navigationnels
        //oneToMany
        private Ordonnance ordonnance;

        public int Id { get => id; set => id = value; }
        public string Code { get => code; set => code = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Posologie { get => posologie; set => posologie = value; }
        public Ordonnance Ordonnance { get => ordonnance; set => ordonnance = value; }
    }
}
