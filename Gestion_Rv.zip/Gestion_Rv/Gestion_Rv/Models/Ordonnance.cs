﻿using Gestion_Rv.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public class Ordonnance
    {
        private int id;
        private string libelle;
        //Attributs navigationnels
        //OneToMany
        private Patient patient;
        private Consultation consultation;
        //ManyToOne
        private List<Medicament> medicaments;
       
        public int Id { get => id; set => id = value; }
        public string Libelle { get => libelle; set => libelle = value; }
        public List<Medicament> Medicaments { get => medicaments; set => medicaments = value; }
        public Patient Patient { get => patient; set => patient = value; }

        public override string ToString()
        {
            return Libelle;
        }
    }
}
