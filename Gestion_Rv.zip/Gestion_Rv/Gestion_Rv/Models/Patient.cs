﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public class Patient:User
    {

        private string code;
        private string email;
        private string tel;
        //attributs navigationnels
        //many to one
        List<RendezVous> rv;
        List<Consultation> consultations;
        List<Prestation> prestations;
        List<Ordonnance> ordonnance;
        List<AntecedentsMedicaux> antedentsMedicaux;
      
        public Patient()
        {
            role= Role.Patient;
        }

        public string Code { get => code; set => code = value; }
        public string Email { get => email; set => email = value; }
        public string Tel { get => tel; set => tel = value; }

        public List<RendezVous> Rv { get => rv; set => rv = value; }
        public List<Consultation> Consultations { get => consultations; set => consultations = value; }
        public List<Prestation> Prestations { get => prestations; set => prestations = value; }
        public List<Ordonnance> Ordonnance { get => ordonnance; set => ordonnance = value; }
        public List<AntecedentsMedicaux> AntedentsMedicaux { get => antedentsMedicaux; set => antedentsMedicaux = value; }

        public override string ToString()
        {
            return Nom+" "+prenom;
        }
    }
}
