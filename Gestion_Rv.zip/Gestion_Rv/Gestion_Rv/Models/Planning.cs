﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public class Planning
    {
        private int id;
        private string jour;
        private string horaireDebut;
        private string horaireFin;

        //Attributs navigationnels
        //OneToMany
        private User user;

        public string Jour { get => jour; set => jour = value; }
        public string HoraireDebut { get => horaireDebut; set => horaireDebut = value; }
        public string HoraireFin { get => horaireFin; set => horaireFin = value; }
        public User User { get => user; set => user = value; }
        public int Id { get => id; set => id = value; }
    }
}
