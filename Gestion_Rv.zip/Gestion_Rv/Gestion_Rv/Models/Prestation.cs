﻿using Gestion_Rv.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public enum TypePrestation
    {
        Analyse,Radio
    }
    public class Prestation 
    {
        private int id;
        private string date;
        private string type;
        //Attributs navigationnels
        //one to many
        private Patient patient;
        private RP rp;
        private RendezVous rdv;

        public string Type { get => type; set => type = value; }
        public int Id { get => id; set => id = value; }
        public string Date { get => date; set => date = value; }
        public Patient Patient { get => patient; set => patient = value; }
        public RP Rp { get => rp; set => rp = value; }
        public RendezVous Rdv { get => rdv; set => rdv = value; }
    }
}
