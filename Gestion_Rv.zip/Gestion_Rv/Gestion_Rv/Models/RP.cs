﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public class RP : User
    {
        //ManyToOne
        private List<Prestation> prestations;
        public RP()
        {
            role=Role.RP;
        }
    }
}
