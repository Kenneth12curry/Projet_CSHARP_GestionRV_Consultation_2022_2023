﻿using Gestion_Rv.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{
    public class RendezVous
    {
        protected int id;
        protected string date;
        protected string etat;
        protected string type;
        private string heure;
        //Atrributs navigationnels
        //OneToMany

        private Patient patient;
        private User user;
        private Consultation consultation;
        private Prestation prestation;

       
        

        public RendezVous()
        {
            Etat = "Confirmer";
        }

        public string Etat { get => etat; set => etat = value; }
        public int Id { get => id; set => id = value; }
        public string Date { get => date; set => date = value; }
        public string Type { get => type; set => type = value; }
        public string Heure { get => heure; set => heure = value; }
        public Patient Patient { get => patient; set => patient = value; }
        public User Traitant { get => user; set => user = value; }

       
    }
}
