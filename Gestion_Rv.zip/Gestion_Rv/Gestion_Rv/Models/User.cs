﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Models
{

    public enum Role
    {
        Patient, Secretaire, Medecin, RP
    }


    public class User
    {
        
        protected int id;
        protected string login;
        protected string password;
        protected string nom;
        protected string prenom;
        protected Role role;
        //Attributs navigationnels
        //ManyToOne
        private List<Planning> planning=new List<Planning>();
        private List<RendezVous> rdv=new List<RendezVous>();

        public User()
        {
        }

        public User(string login, string password, string nom, string prenom)
        {
            this.login = login;
            this.password = password;
            this.nom = nom;
            this.prenom = prenom;
        }

        public User(int id, string login, string password, string nom, string prenom, Role role)
        {
            this.id = id;
            this.login = login;
            this.password = password;
            this.nom = nom;
            this.prenom = prenom;
            Role = role;
        }


        public int Id { get => id; set => id = value; }
        public string Login { get => login; set => login = value; }
        public string Password { get => password; set => password = value; }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        public Role Role { get => role; set => role = value; }
        public List<Planning> Planning { get => planning; set => planning = value; }
        public List<RendezVous> Rdv { get => rdv; set => rdv = value; }

        public override string ToString()
        {
            return Prenom+" "+Nom;
        }
    } 
}
