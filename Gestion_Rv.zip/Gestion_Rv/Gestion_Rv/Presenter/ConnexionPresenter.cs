﻿using Gestion_Rv.Models;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class ConnexionPresenter:IConnexionPresenter
    {
        //Couplage faible

        private ISecurityService securityService;
        private IConnexionView connexionView;

        public static User user;

        public ConnexionPresenter(IConnexionView connexionView)
        {
            this.connexionView = connexionView;
            securityService=FabriqueService.GetSecurityService();
            this.callBackEvent();
            this.connexionView.Show();

        }

        //Création de la fonction callBackEvent
        public void callBackEvent()
        {
            //Mapping => écouteurs d'évènements
            this.connexionView.ConnexionEvent += ConnexionEventHandle;

        }
       
        private void ConnexionEventHandle(object sender, EventArgs e)
        {
            string login=this.connexionView.Login;
            string password = this.connexionView.Password;
            user=securityService.seConnecter(login, password);

            if(user!=null)
            {
                this.connexionView.IsLoggedIn= true;
                //Création de la view Menu
                IMenuView menuView = new FormMenu();
                //Récupération de l'utilisateur qui est connecté
                menuView.userConnect = user;
                //Création de menuPresenter
                IMenuPresenter menuPresenter = new MenuPresenter(menuView);
                //Ne plus afficher la page de connexion après que l'utilisateur s'est connecté
                connexionView.Hide();

            }
            else
            {
                this.connexionView.IsLoggedIn = false;
                this.connexionView.Message = "Login ou Mot de passe Incorrect";
            }
        }

        public IConnexionView ConnexionView { get => connexionView; set => connexionView = value; }

    }
}
