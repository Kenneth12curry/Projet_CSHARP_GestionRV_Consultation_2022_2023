﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class ConsultationPresenter:IConsultationPresenter
    {
        private IConsultationService consultationService;
        private IPatientService patientService;
        private IConsultationView consultationView;
        

        public ConsultationPresenter(IConsultationView consultationView)
        {
            this.consultationView = consultationView;
            consultationService=FabriqueService.GetConsultationService();
            patientService=FabriqueService.GetPatientService();
            this.consultationView.Show();
            this.initialize();
            //Mapping => Ecouteurs d'évènements
            this.consultationView.showFiltreConsultationEvent += showFiltreConsultationEventHandle;
            this.consultationView.showFormDetailsConsultationsEvent += showFormDetailsConsultationsEventHandle;
        }

       
        //BidingSource 
        private BindingSource bindingConsultation = new BindingSource();
        private BindingSource bindingpatient = new BindingSource();

        //List => Collections de list
        IEnumerable<ConsultationDto> consultationList = new List<ConsultationDto>();
        IEnumerable<PatientDto> patientList = new List<PatientDto>();

        private void initialize()
        {
            ShowConsultationByUser();
            //consultationList = consultationService.listerConsultation();
            //bindingConsultation.DataSource= consultationList;
            patientList = patientService.listerPatient();
            bindingpatient.DataSource= patientList;
            this.consultationView.setConsultationBidingSource(bindingConsultation, bindingpatient);
        }

        User user = ConnexionPresenter.user;

        private void showConsultationsByUser(string date, User user)
        {
            //liste des consultations de la journée du médecin
            consultationList = consultationService.listerConsultationMedecin(date, user);
            bindingConsultation.DataSource = consultationList;

        }
        private void showConsultations(string date)
        {
            //lister les consultations de la journée
            consultationList = consultationService.listerConsultationParDate(date);
            bindingConsultation.DataSource = consultationList;
        }

        private void ShowConsultationByUser()
        {
            //Récupération de la date du jour + Conversion en string 
            string date = DateTime.Now.ToShortDateString();

            if (user.Role == Role.Medecin)
            {
                showConsultationsByUser(date, user);
                //Désactiver le panel
                this.consultationView.PanelPatient = false;

            }
            if (user.Role == Role.Secretaire)
            {
                showConsultations(date);
            }
        }

        private void showFiltreConsultationsByDate(string date)
        {
            if (user.Role == Role.Medecin)
            {
                showConsultationsByUser(date, user);
            }
            else
            {
                showConsultations(date);
            }
        }

        private void showFiltreConsultationEventHandle(object sender, EventArgs e)
        {
            var btn = sender as Button;
            if(btn.Name == "btnDate")
            {
                DateTime date = this.consultationView.Date;
                showFiltreConsultationsByDate(date.ToShortDateString());
                
            }
            else if (btn.Name == "btnPatient")
            {
                PatientDto patient = this.consultationView.listPatient;
                consultationList=consultationService.findConsultationsPatients(patient.toPatient());
                bindingConsultation.DataSource= consultationList;

            }

        }

        //Redirection vers la page de détails d'une consultation


        DetailsConsultationPresenter consultationPresenter=null;
        private void showFormDetailsConsultationsEventHandle(object sender, EventArgs e)
        {
            ConsultationDto consultation = bindingConsultation.Current as ConsultationDto;
            Consultation consultation1 = consultationService.rechercherConsultation(consultation.Id);

            if (consultationPresenter == null)
            {
                consultationPresenter = new DetailsConsultationPresenter(consultation1, new FormDetailsConsultation()) ;

            }
            else
            {
                consultationPresenter.Views = new FormDetailsConsultation();
                consultationPresenter.Consultation = consultation1;
                consultationPresenter.initialize();
                consultationPresenter.Views.Show();
            }

        }

    }
}
