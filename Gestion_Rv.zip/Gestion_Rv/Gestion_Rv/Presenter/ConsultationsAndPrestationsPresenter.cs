﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class ConsultationsAndPrestationsPresenter:IConsultationsAndPrestationsPresenter
    {
        private PatientDto patient;
        private IConsultationsAndPrestationsPatientView views;
        private IConsultationService consultationService;
        private IPrestationService prestationService;


        public ConsultationsAndPrestationsPresenter(PatientDto patient,IConsultationsAndPrestationsPatientView views)
        {
            this.patient = patient;
            this.views = views;
            consultationService=FabriqueService.GetConsultationService();
            prestationService = FabriqueService.GetPrestationService();
            this.initialize();
            this.views.Show();

        }


        //Biding Source
        BindingSource bindingconsultation = new BindingSource();
        BindingSource bindingprestation = new BindingSource();

        //List<Collections>
        IEnumerable<Consultation> consultationList = new List<Consultation>();
        IEnumerable<PrestationDto> prestationList = new List<PrestationDto>();

        public void initialize()
        {
            //Chargement des informations à l'initialisationde la page
            this.views.nomPatient = patient.Nom;
            this.views.prenomPatient = patient.Prenom;
            this.views.codePatient = patient.Code;
            consultationList = consultationService.listerConsultationParPatient(patient.toPatient());
            bindingconsultation.DataSource = consultationList;
            this.views.setConsultationsAndPrestationBidingSource(bindingconsultation);

            //Mapping => écouteurs d'évènements

            this.views.showFormEvent += showFormEventHandle;
            this.views.closeFenenetreEvent += closeFenenetreEventHandle;
        }

       
        private void showFormEventHandle(object sender, EventArgs e)
        {
            var btn = sender as Button;
            if (btn.Name == "btnPrestation")
            {
                prestationList = prestationService.listerPrestationParPatient(patient.toPatient());
                bindingprestation.DataSource = prestationList;
                this.views.setConsultationsAndPrestationBidingSource(bindingprestation);
            }
            else
            {
                consultationList = consultationService.listerConsultationParPatient(patient.toPatient());
                bindingconsultation.DataSource = consultationList;
                this.views.setConsultationsAndPrestationBidingSource(bindingconsultation);
            }
           
        }

        private void closeFenenetreEventHandle(object sender, EventArgs e)
        {
            this.views.Dispose();
        }

        public PatientDto Patient { get => patient; set => patient = value; }
        public IConsultationsAndPrestationsPatientView Views { get => views; set => views = value; }

    }
}
