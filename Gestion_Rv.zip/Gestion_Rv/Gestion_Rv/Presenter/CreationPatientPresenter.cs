﻿using Gestion_Rv.Models;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class CreationPatientPresenter:ICreationPatientPresenter
    {
        private ICreationPatientView creationPatientView;
        private IPatientService patientService;


        public CreationPatientPresenter(ICreationPatientView creationPatientView)
        {
            this.creationPatientView = creationPatientView;
            patientService = FabriqueService.GetPatientService();
            this.CreationPatientView.Show();
            initialize();
        }
        
        public void initialize()
        {
            //Mapping
            this.creationPatientView.ajouterPatientEvent += ajouterPatientEventHanlde;
        }

        private void ajouterPatientEventHanlde(object sender, EventArgs e)
        {
            string nom = this.creationPatientView.nomPatient;
            string prenom = this.creationPatientView.prenomPatient;
            string email = this.creationPatientView.emailPatient;
            string tel = this.creationPatientView.telPatient;
            //string antecedents=this.creationPatientView.an
            if (string.IsNullOrEmpty(nom)|| string.IsNullOrEmpty(prenom) ||
                string.IsNullOrEmpty(email) || string.IsNullOrEmpty(tel))
            {
                MessageBox.Show("veullez remplir tous les champs!");
            }
            else
            {
                Patient patient = new Patient()
                {
                    Nom= nom,
                    Prenom=prenom,
                    Code = "PAT_00" + patientService.listerPatient().Count() + 1,
                    Email =email,
                    Tel=tel,
                };
                try
                {
                    patientService.creerPatient(patient);
                    MessageBox.Show("Patient créé avec succès");
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }
        public ICreationPatientView CreationPatientView { get => creationPatientView; set => creationPatientView = value; }
    }
}
