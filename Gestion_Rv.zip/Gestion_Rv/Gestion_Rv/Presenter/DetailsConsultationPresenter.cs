﻿using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class DetailsConsultationPresenter:IDetailsConsultationPresenter
    {
        private Consultation consultation;
        private IDetailsConsultationView views;
        private IOrdonnanceAndMedicamentService service;

        public DetailsConsultationPresenter(Consultation consultation,IDetailsConsultationView views)
        {
            this.consultation = consultation;
            this.views = views;
            service=FabriqueService.GetOrdonnanceAndMedicamentService();
            this.initialize();
            this.views.Show();
        }

        //BidinSource
        private BindingSource bindingOrdonnance = new BindingSource();
        private BindingSource bindingMedicament = new BindingSource();
        //List<Collections>
        IEnumerable<Ordonnance> ordonnanceList = new List<Ordonnance>();
        IEnumerable<Medicament> medicamentList = new List<Medicament>();

        

        public void initialize()
        {
            //Informations du Patient
            this.views.nomPatient = consultation.Patient.Nom;
            this.views.prenomPatient = consultation.Patient.Prenom;
            this.views.codePatient = consultation.Patient.Code;
            //Informations sur la Consultation
            this.views.date = consultation.Date.ToString();
            this.views.temperature = consultation.Temperature;
            this.views.tension = consultation.Tension;
            this.views.poids = consultation.Poids;
            this.views.motif = consultation.Motif;
            //Informations sur le Medecin
            this.views.nomMedecin = consultation.Medecin.Nom;
            this.views.prenomMedecin = consultation.Medecin.Prenom;
            this.views.typeMedecin = consultation.Medecin.Type.ToString();
            //Initialisation de la liste des ordonnances du patient
            ordonnanceList = service.listerOrdonnannceUnPatient(consultation.Patient);
            bindingOrdonnance.DataSource= ordonnanceList;
            this.views.setBidingSource(bindingOrdonnance);
            //Appel de la fonction callBackEvent;
            callBackEvent();
        }

        public void callBackEvent()
        {
            //Mapping ecouteurs d'évènements
            this.views.SelectionLigneDtgvEvent += SelectionLigneDtgvHandle;


        }

        private void SelectionLigneDtgvHandle(object sender, EventArgs e)
        {
            Ordonnance ordonnance= bindingOrdonnance.Current as Ordonnance;
            medicamentList=service.listerMedicamentUneOrdonnance(ordonnance);
            bindingMedicament.DataSource= medicamentList;
            this.views.setMedicamentBidingSource(bindingMedicament);
        }


        public Consultation Consultation { get => consultation; set => consultation = value; }
        public IDetailsConsultationView Views { get => views; set => views = value; }

        


    }
}
