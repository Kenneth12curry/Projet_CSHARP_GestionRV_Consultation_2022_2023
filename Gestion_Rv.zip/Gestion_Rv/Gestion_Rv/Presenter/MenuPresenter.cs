﻿using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class MenuPresenter : IMenuPresenter
    {
        private IMenuView menuView;

        public MenuPresenter(IMenuView menuView)
        {
            this.menuView = menuView;
            this.initialize();
            //appel de la méthode Show() dans IMenuView pour afficher la page menu après la connexion
            this.menuView.Show();
            
        }

        private void initialize()
        {
            //Affichage du nom complet de l'utilisateur qui est connecté dans la page menu
            this.menuView.userLabel = this.menuView.userConnect.Prenom+" "+this.menuView.userConnect.Nom;
            //mapping => écouteurs d'évènements
            this.menuView.showFormEvent += showFormEventHandle;
            activeMenuByUser();
        }

        private void activeMenuByUser()
        {
            if (menuView.userConnect.Role == Role.Medecin)
            {
                isMedecin();
            }
            if(menuView.userConnect.Role== Role.RP)
            {
                isRP();
            }
        }
        private void isRP()
        {
            menuView.consultation = false;
            menuView.patient= false;
            menuView.planning= false;
        }

        private void isMedecin()
        {
            menuView.prestation = false;
            menuView.planning=false;

        }

        IPlanningRepository planningRepository;

        ConnexionPresenter connexionPresenter = null;
        private void showFormEventHandle(object sender, EventArgs e)
        {
            var btn = sender as Button;
            if (btn.Name == "btnRv")
            {
                //Fenêtre de RendezVous
                IRendezVousView rvView = FormRendezVous.showForm(menuView as Form);//FormRendezVous pour afficher  la page en dehors du menu
                new RendezVousPresenter(rvView);
            }
            else if (btn.Name == "btnPrestation")
            {
                //Fenêtre de Prestation
                IPrestationView prestationView = FormPrestation.showForm(menuView as Form);//FormPrestation pour afficher  la page en dehors du menu
                new PrestationPresenter(prestationView);
            }
            else if(btn.Name == "btnConsultation")
            {
                //Fenêtre de Consultation
                IConsultationView consultationView = FormConsultation.showForm(menuView as Form);//FormConsultation pour afficher  la page en dehors du menu
                new ConsultationPresenter(consultationView);
            }
            else if(btn.Name == "btnPatient")
            {
                //Fenêtre de Consultation
                IPatientView patientView = FormPatient.showForm(menuView as Form);//FormPatient pour afficher  la page en dehors du menu
                new PatientPresenter(patientView);
            }
            else if (btn.Name == "btnPlanning")
            {
                //Fenêtre de Planning
                IPlanningViews planningView = FormPlanningViews.showForm(menuView as Form);//FormPatient pour afficher  la page en dehors du menu
                new PlanningPresenter(planningView);
            }
            else 
            {
                //Fenêtre de Connnexion
                connexionPresenter = new ConnexionPresenter(new FormConnexion());
                menuView.Dispose();
                
               
            }
                
         }

           
    }

 }

