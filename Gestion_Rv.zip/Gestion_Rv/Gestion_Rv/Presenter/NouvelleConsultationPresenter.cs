﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication.ExtendedProtection.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class NouvelleConsultationPresenter:INouvelleConsultationPresenter
    {
        private RendezVous rdv;
        private INouvelleConsultationView views;
        private IConsultationService consultationService;
        private IMedecinService medecinService;
        private IOrdonnanceAndMedicamentService service;
        private IRendezVousService rendezVousService;

        public NouvelleConsultationPresenter(RendezVous rdv,INouvelleConsultationView views)
        {
            this.views = views;
            this.rdv = rdv;
            consultationService=FabriqueService.GetConsultationService();
            medecinService = FabriqueService.GetMedecinService();
            service = FabriqueService.GetOrdonnanceAndMedicamentService();
            rendezVousService=FabriqueService.GetRendezVousService();
            this.views.Show();
            this.initialize();
            this.callBackEvent();
            // Désactiver le group box qui contient les informations de l'ordonnance à l'initialisation de la page
            this.views.groupBoxOrdonnance = false;
            
        }

        //BidingSource
        private BindingSource bindingMedecin = new BindingSource();
        private BindingSource bindingPatient = new BindingSource();

        //List => Collections
        IEnumerable<Medecin> medecinList = new List<Medecin>();
        

        public void initialize()
        {
            this.views.Date = rdv.Date;
            this.views.Medecin = rdv.Traitant.Prenom +" "+rdv.Traitant.Nom;
            this.views.Patient = rdv.Patient.Prenom +" "+rdv.Patient.Nom;

            //Générer un libellé pour la création de l'ordonnance

            string numero = "Ordonnance_N°" + service.listerOrdonnance().Count() + 1;
            this.views.saisieNumeroOrdonnance = numero;

            //Désactiver la panel
            this.views.panelConsultation = false;
            this.views.panelMed = false;
            this.views.panelOrdonnance = false;
            this.views.libelleOrdonnance = false;
            this.views.enregistrerEvent += enregistrerConsultationEventHandle;

        }
       
        private void callBackEvent()
        {
            //Mapping => écouteurs d'évènements
            this.views.ajoutMedEvent += ajoutEventHandle;
            this.views.radioButtonEvent += radioButtonEventHandle;
            this.views.creerOrdonnanceEvent += creerOrdonnanceEventHandle;
           

        }


        private void radioButtonEventHandle(object sender, EventArgs e)
        {
            var btn = sender as Button;
            if (this.views.checkedRadio)
            {
                this.views.groupBoxOrdonnance = true;
            }
            else
            {
                this.views.groupBoxOrdonnance = false;
            }
        }

        public Ordonnance ordonnance;

        private void creerOrdonnanceEventHandle(object sender, EventArgs e)
        {
            string libelle=this.views.saisieNumeroOrdonnance;
            ordonnance = new Ordonnance() { Libelle = libelle, Patient = rdv.Patient, };
            ordonnance = service.creerOrdonnance(ordonnance);
            MessageBox.Show("Ordonnance créer avec succès !");
            //Activation du panel pour l'ajout des médicaments
            this.views.panelMed = true;
            
           
        }

        private void message()
        {
            MessageBox.Show("Veuillez s'il vous plaît Remplir tous les champs!");
        }

         
        
        private void enregistrerConsultationEventHandle(object sender, EventArgs e)
        {
           
            string temperature = this.views.saisieTemperature;
            string tension = this.views.saisieTension;
            string poids=this.views.saisiePoids;
            string motif = this.views.saisieMotif;

            if (string.IsNullOrEmpty(views.saisieTemperature) || string.IsNullOrEmpty(views.saisieTension)
                || string.IsNullOrEmpty(views.saisiePoids) || string.IsNullOrEmpty(views.saisieMotif))
            {
                this.message();
            }
            else
            {
                Consultation consultation = new Consultation()
                {
                    Date = rdv.Date,
                    Medecin = medecinService.rechercherMedecin(rdv.Traitant.Id),
                    Patient = rdv.Patient,
                    Temperature = temperature,
                    Tension = tension,
                    Poids = poids,
                    Motif = motif,
                    Rdv = rdv
                   
                };

                try
                {
                    consultationService.enregistrerConsultation(consultation);
                    MessageBox.Show("une nouvelle Consultation vient d'être ajoutée");
                    //Activaction du groupeBox Ordonnance
                    this.views.panelOrdonnance = true;
                    //Changer Etat du rendez-vous
                    rdv.Etat = "Terminer";
                    rendezVousService.modifierRdv(rdv);
                    
                }
                catch (Exception)
                {
                    throw;
                }
            }
            
        }

        private void ajoutEventHandle(object sender, EventArgs e)
        {
            string libelle = this.views.saisieNumeroOrdonnance;
            string code=this.views.saisieCode;
            string nom = this.views.saisieNom;
            string posologie = this.views.saisiePosologie;
            Medicament codeMed = service.searchCode(code);
            ordonnance = service.rechercherOrdonnance(libelle);
            if (ordonnance != null)
            {
                if (codeMed == null)
                {
                    Medicament medicament = new Medicament()
                    {
                        Code = code,
                        Nom = nom,
                        Posologie = posologie,
                        Ordonnance = ordonnance
                    };
                    try
                    {
                        service.creerMedicament(medicament);
                        MessageBox.Show("le Medicament a été ajouté à cette ordonnance");
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez changer le code du médicament !");
                }
               

            }
            else
            {
                MessageBox.Show("Ce médicament ne peut pas être ajouter sur cette ordonnance car il n'existe pas");
                /*ordonnance = new Ordonnance()
                {
                    Libelle= numero,
                    Patient=rdv.Patient,

                };
                ordonnance=service.creerOrdonnance(ordonnance);
                Medicament medicament = new Medicament()
                {
                    Code = code,
                    Nom = nom,
                    Posologie = posologie,
                    Ordonnance = ordonnance
                };
                service.creerMedicament(medicament);*/
            }
        }


        public RendezVous Rdv { get => rdv; set => rdv = value; }
        public INouvelleConsultationView Views { get => views; set => views = value; }

    }
}
