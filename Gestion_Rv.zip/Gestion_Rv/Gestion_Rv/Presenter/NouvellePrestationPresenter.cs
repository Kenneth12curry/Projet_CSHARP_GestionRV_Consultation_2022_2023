﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class NouvellePrestationPresenter:INouvellePrestationPresenter
    {
        private RendezVous rdv;
        private INouvellePrestationView views;
        private IPrestationService prestationService;
        private IUserService userService;
        private IRendezVousService rendezVousService;

        public NouvellePrestationPresenter(RendezVous rdv,INouvellePrestationView views)
        {
            this.views = views;
            this.rdv = rdv;
            prestationService=FabriqueService.GetPrestationService();
            userService=FabriqueService.GetUserService();
            rendezVousService=FabriqueService.GetRendezVousService();
            this.views.Show();
            this.initiliaze();
        }

        //BidingSource 
        private BindingSource bindingprestation = new BindingSource();
        
        //List<Collections>
        IEnumerable<String> prestationList=new List<String>();


        public void initiliaze()
        {
            //Chargement des iformations pour la prestation
            this.views.Date = rdv.Date;
            this.views.Patient = rdv.Patient.Prenom + " " + rdv.Patient.Nom;
            //Désactiver le panel
            this.views.prestation = false;

            List<string> list = new List<string>()
            {
                "Analyse",
                "Radio",
            };
            prestationList = list;
            bindingprestation.DataSource = prestationList;
            this.views.setBidingSource(bindingprestation);

            //Mapping => écouteurs d'évvènements
            this.views.enregistrerAndannulerPrestationEvent += enregistrerPrestationEventHandle;

        }


        private void enregistrerPrestationEventHandle(object sender, EventArgs e)
        {
          
            string typePrestation = this.views.typePrestation;
    
            Prestation prestation = new Prestation()
            {
                Date = rdv.Date,
                Type = typePrestation,
                Patient=rdv.Patient,
                Rp=userService.rechercherRp(rdv.Traitant.Id),
                Rdv=rdv
                    
            };
            try
            {
                prestationService.EnregisterPrestation(prestation);
                MessageBox.Show("Une nouvelle prestation vient d'être enregistrée");
                //Change l'2tat du rendez-vous
                rdv.Etat = "Terminer";
                rendezVousService.modifierRdv(rdv);

            }
            catch (Exception ex)
            {

                throw ex;
            }
        
        }
        public RendezVous Rdv { get => rdv; set => rdv = value; }
        public INouvellePrestationView Views { get => views; set => views = value; }
    }
}
