﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Gestion_Rv.Presenter
{
    public class PatientPresenter : IPatientPresenter
    {
        private IPatientView patientView;
        private IPatientService patientService;


        public PatientPresenter(IPatientView patientView)
        {
            this.patientView = patientView;
            patientService = FabriqueService.GetPatientService();
            patientView.Show();
            callBackEvent();
            initialize();
            
        }

        //BindingSource

        private BindingSource bindingPatient = new BindingSource();

        //List
        /*Toutes les collections (Liste) implémentent l'interface*/

        IEnumerable<PatientDto> patientList = new List<PatientDto>();


        Patient patientSelect;

        private void initialize()
        {
            //BidingSource
            patientList = patientService.listerPatient();
            bindingPatient.DataSource = patientList;
            this.patientView.setPatientlist(bindingPatient);
            if (ConnexionPresenter.user.Role == Role.Medecin)
            {
                this.patientView.patient = false;
                this.patientView.planifierRdv = false;
                
            }
            else
            {
                this.patientView.DossierMedical=false;
            }
        }

        private void callBackEvent()
        {
            //Mapping => écouteurs d'événements
            this.patientView.showPatientEvent += showPatientEventHandle;
            this.patientView.loadViewConsultationsAndPrestationsUnPatient += loadViewConsultationsAndPrestationsUnPatientHandle;
            this.patientView.rechercherPatientEvent += rechercherPatientEventHandle;
            this.patientView.nouveauRvEvent += nouveauRvEventHandle;

        }

     

        RdvNouveauPresenter presenter = null;
        private void nouveauRvEventHandle(object sender, EventArgs e)
        {
            PatientDto patient = bindingPatient.Current as PatientDto;
            if (presenter == null)
            {
                presenter = new RdvNouveauPresenter(patient.toPatient(),new FormNouveauRv());
            }
            else
            {
                presenter.NouveauRvView = new FormNouveauRv();
                presenter.Patient= patient.toPatient();
                presenter.initiliaze();
                presenter.NouveauRvView.Show();
            }
        }

        CreationPatientPresenter patientPresenter = null;
        private void showPatientEventHandle(object sender, EventArgs e)
        {
            if (presenter == null)
            {
                patientPresenter = new CreationPatientPresenter(new FormCreationPatient());
            }
            else
            {
                patientPresenter.CreationPatientView = new FormCreationPatient();
             
            }
            
        }

        private void rechercherPatientEventHandle(object sender, EventArgs e)
        {
            string tel = this.patientView.nomRecherche;
            if (!string.IsNullOrWhiteSpace(patientView.nomRecherche))
            {
                PatientDto patient= patientService.rechercherPatient(tel);
                bindingPatient.DataSource = patient;

            }
            else
            {
                patientList = patientService.listerPatient();
                bindingPatient.DataSource = patientList;
            }

            
        }

        ConsultationsAndPrestationsPresenter consultationsAndPrestationsPresenter=null;
        private void loadViewConsultationsAndPrestationsUnPatientHandle(object sender, EventArgs e)
        {
            PatientDto patient = bindingPatient.Current as PatientDto;
            if (consultationsAndPrestationsPresenter == null)
            {
               
                consultationsAndPrestationsPresenter=new ConsultationsAndPrestationsPresenter(patient, new FormConsultationsAndPrestationsPatient());

            }
            else
            {
                consultationsAndPrestationsPresenter.Views = new FormConsultationsAndPrestationsPatient();
                consultationsAndPrestationsPresenter.Patient = patient;
                consultationsAndPrestationsPresenter.initialize();
                consultationsAndPrestationsPresenter.Views.Show();
            }
           
        }

    }
}

