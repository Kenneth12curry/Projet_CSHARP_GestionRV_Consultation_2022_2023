﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class PlanningPresenter:IPlanningPresenter
    {
        private IPlanningViews planningViews;
        private IPlanningService planningService;
        private IUserService userService;

        public PlanningPresenter(IPlanningViews planningViews)
        {
            this.planningViews = planningViews;
            planningService = FabriqueService.GetPlanningService();
            userService=FabriqueService.GetUserService();
            initialize();
            callBackEvent();
            this.planningViews.Show();

        }

        //BidingSource

        private BindingSource bindingPlanning = new BindingSource();
        private BindingSource bindingUser = new BindingSource();
        private BindingSource bindingTypeRole = new BindingSource();
        private BindingSource bindingHorairelistDebut = new BindingSource();
        private BindingSource bindingHorairelistFin = new BindingSource();
        private BindingSource bindingJour = new BindingSource();

        //List=>Collections

        IEnumerable<Planning> planningList= new List<Planning>();
        IEnumerable<UserDto> userList = new List<UserDto>();
        List<string> horairelist = new List<string>();
        IEnumerable<string> listType = new List<string>() {"Généraliste","Spécialiste","RP"};
        IEnumerable<string> jourList = new List<string>(){"Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"};

        private void initialize()
        {
            //Chargement list des médecins par type
            userList = userService.listeUser("Medecin","Généraliste");
            bindingUser.DataSource = userList;
            //Chargement list des types par role
            bindingTypeRole.DataSource = listType;
            //Chargement liste des horaires
            for (int i = 8; i < 25; i++)
            {
                horairelist.Add(i.ToString()+"H");
            };
            bindingHorairelistDebut.DataSource=horairelist;
            bindingHorairelistFin.DataSource = horairelist;
            //Chargement des jour de la semaine
            bindingJour.DataSource=jourList;
            this.planningViews.setBindingSource(bindingUser, bindingTypeRole, 
                bindingHorairelistDebut,bindingHorairelistFin, bindingJour) ;
            
        }
       

        private void callBackEvent()
        {
            //Mapping => écouteurs d'évènements
            this.planningViews.filtrerUserByRoleEvent += filtrerUserEventHandle;
            this.planningViews.AjouterPlanningMedecinEvent += AjouterPlanningEventHandle;
            this.planningViews.SelectionLigneDtgvEvent += SelectionLigneDtgvEventHandle;

        }

        private void filtrerUserEventHandle(object sender, EventArgs e)
        {
            string type = this.planningViews.typeRole;
            if (type.CompareTo("Généraliste") == 0)
            {

                userList = userService.listeUser("Medecin", type);
                bindingUser.DataSource = userList;
            }
            else if (type.CompareTo("Spécialiste") == 0)
            {

                userList = userService.listeUser("Medecin", type);
                bindingUser.DataSource = userList;
            }
            else if (type.CompareTo("RP") == 0)
            {
                userList = userService.listeUserByRole(type);
                bindingUser.DataSource = userList;
            }

        }

        private void SelectionLigneDtgvEventHandle(object sender, EventArgs e)
        {
            UserDto user=bindingUser.Current as UserDto;
            User user1 = userService.rechercherUser(user.Id);
            planningList = planningService.listerPlanningByUser(user1);
            bindingPlanning.DataSource = planningList;
            this.planningViews.setPlanningBindingSource(bindingPlanning);

        }

       

       
        private void AjouterPlanningEventHandle(object sender, EventArgs e)
        {
            string jour=this.planningViews.jourSemaine;
            string horaireDebut =this.planningViews.horaireDebut;
            string horaireFin =this.planningViews.horaireFin;
            //Récupérer un utilisateur séléctionnée dans le tableau
            UserDto user = bindingUser.Current as UserDto;
            if(horaireDebut.CompareTo(horaireFin) == 0)
            {
                MessageBox.Show("Veuillez séléctionner des Horaires de Début et de Fin différentes ");
            }
            else
            {
                Planning planning = planningService.rechercherPlanning(user.toUser(), jour, horaireDebut, horaireFin);
                if (planning == null)
                {
                    Planning planning1 = new Planning()
                    {
                        Jour = jour,
                        HoraireDebut = horaireDebut,
                        HoraireFin = horaireFin,
                        User = user.toUser()
                    };
                    try
                    {
                        planningService.creerPlanning(planning1);
                        MessageBox.Show("Planning ajoutée avec succès");
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                }
                else if(planning!=null)
                {
                    MessageBox.Show("Ce médecin ou RP est déja programmée pour ce jour et ces Horaires");
                }
               
            }
        }
    }
}
