﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Presenter
{
    public class PrestationPresenter:IPrestationPresenter
    {
        private IPrestationService prestationService;
        private IPrestationView prestationView;
        private IPatientService patientService;

        public PrestationPresenter(IPrestationView prestationView)
        {

            this.prestationView = prestationView;
            prestationService=FabriqueService.GetPrestationService();
            patientService = FabriqueService.GetPatientService();
            this.prestationView.Show();
            this.callBackEvent();
            this.initiliaze();

        }

        //BidingSource 
        private BindingSource bindingprestation = new BindingSource();
        private BindingSource bindingpatient = new BindingSource();

        //List => Collections de list
        IEnumerable<PrestationDto> prestationList = new List<PrestationDto>();
        IEnumerable<PatientDto> patientList = new List<PatientDto>();

        private void initiliaze()
        {
            ShowPrestationsByUser();
            patientList = patientService.listerPatient();
            bindingpatient.DataSource = patientList;
            this.prestationView.setPrestationBidingSource(bindingprestation,bindingpatient);
        }

        User user = ConnexionPresenter.user;

        private void showPrestationsByUser(string date, User user)
        {
            //liste de scosnultations de la journée du RP
            prestationList = prestationService.listerPrestationsUNRp(date, user);
            bindingprestation.DataSource = prestationList;

        }
        private void showPrestations(string date)
        {
            //lister les consultations de la journée
            prestationList = prestationService.listerPrestationParDate(date);
            bindingprestation.DataSource = prestationList;
        }

        private void ShowPrestationsByUser()
        {
            //Récupération de la date du jour + Conversion en string 
            string date = DateTime.Now.ToShortDateString();

            if (user.Role == Role.RP)
            {
                showPrestationsByUser(date, user);
                //Rendre visible le champ patient
                this.prestationView.PanelPatient = false;

            }
            if (user.Role == Role.Secretaire)
            {
                showPrestations(date);
            }

        }


        private void callBackEvent()
        {
            //Mapping => écouteurs d'évènements
            this.prestationView.showFiltreEvent += showFiltreEvent;
            
        }

        private void showFiltrePrestationsByDate(string date)
        {
            if (user.Role == Role.RP)
            {
                showPrestationsByUser(date, user);
            }
            else
            {
               showPrestations(date);
            }
        }

        private void showFiltreEvent(object sender, EventArgs e)
        {
            var btn = sender as Button;
            if (btn.Name == "btnDate")
            {
                DateTime date = this.prestationView.Date;
               showFiltrePrestationsByDate(date.ToShortDateString());

            }
            else if (btn.Name == "btnPatient")
            {
                PatientDto patient = this.prestationView.listPatient;
                prestationList = prestationService.listerPrestationParPatient(patient.toPatient());
                bindingprestation.DataSource = prestationList;
            }
        }
    }
}
