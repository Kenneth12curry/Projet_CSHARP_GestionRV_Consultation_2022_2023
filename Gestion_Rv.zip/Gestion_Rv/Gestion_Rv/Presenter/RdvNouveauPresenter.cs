﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Gestion_Rv.Presenter
{
    public class RdvNouveauPresenter : INouveauRvPresenter
    {
        private Patient patient;
        private INouveauRvView nouveauRvView;
        private IRendezVousService rendezVousService;
        private IUserService userService;
        private INotificationService notificationService;
        private IPlanningService planningService;

        public RdvNouveauPresenter(Patient patient, INouveauRvView nouveauRvView)
        {
            this.patient = patient;
            this.nouveauRvView = nouveauRvView;
            rendezVousService = FabriqueService.GetRendezVousService();
            userService = FabriqueService.GetUserService();
            planningService = FabriqueService.GetPlanningService();
            notificationService = FabriqueService.GetNotificationService();
            this.nouveauRvView.Show();
            this.initiliaze();
            this.callBackEvent();
            

        }

        //Biding Source
        private BindingSource bindingTypeRdv = new BindingSource();
        private BindingSource bindingJour = new BindingSource();
        private BindingSource bindingUser = new BindingSource();
        private BindingSource bindingHoraire = new BindingSource();
        private BindingSource bindingPlanning = new BindingSource();

        //List de collections
        IEnumerable<string> typeRdvList = new List<string>() { "Consultation", "Prestation" };
        IEnumerable<string> jourList = new List<string>() { "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi" };
        List<string> horaireList = new List<string>();
        IEnumerable<UserDto> userList = new List<UserDto>();
        IEnumerable<Planning> planningList = new List<Planning>();
        IEnumerable<RendezVous> rdvList = new List<RendezVous>();

        private void ChargementInforMationsPatient()
        {
            this.nouveauRvView.nomPatient = patient.Nom;
            this.nouveauRvView.prenomPatient = patient.Prenom;
            this.nouveauRvView.codePatient = patient.Code;
            this.nouveauRvView.emailPatient1 = patient.Email;


        }

        public void initiliaze()
        {
           
            //Chargement des informations du patient à l'initialization
            ChargementInforMationsPatient();
            for (int i = 8; i < 18; i++)
            {
                horaireList.Add(i.ToString() + "H");
            };
            bindingJour.DataSource = jourList;
            bindingTypeRdv.DataSource = typeRdvList;
            bindingHoraire.DataSource = horaireList;
            this.nouveauRvView.setList(bindingHoraire, bindingJour, bindingTypeRdv);
            //Initialisation à l'entrée de la vue
            this.nouveauRvView.mail = false;
           

        }

        private void callBackEvent()
        {
            //Mapping => écouteurs d'évènements
            this.nouveauRvView.creerRdvEvent += creerRdvEventHandle;
            this.nouveauRvView.searchEvent += searchEventHandle;
            this.nouveauRvView.SelectionLigneDtgvEvent += SelectionLigneDtgvEventHandle;
            this.nouveauRvView.sendMailEvent += sendMailEventHandle;
        }

        private void searchEventHandle(object sender, EventArgs e)
        {
            string jour = this.NouveauRvView.jour;
            userList = userService.listerUserParJour(jour);
            bindingUser.DataSource = userList;
            this.nouveauRvView.setBindingSource(bindingUser);

        }


        private void SelectionLigneDtgvEventHandle(object sender, EventArgs e)
        {
            UserDto user = bindingUser.Current as UserDto;
            User user1 = userService.rechercherUser(user.Id);
            planningList = planningService.listerPlanningByUser(user1);
            bindingPlanning.DataSource = planningList;
            this.nouveauRvView.setBidingSource(bindingPlanning);

        }

        private void sendMailEventHandle(object sender, EventArgs e)
        {
            string email = this.NouveauRvView.emailPatient;
            string objectMessage = this.NouveauRvView.objectMessage;
            string message = this.NouveauRvView.Message;
            notificationService.sendmail(email, objectMessage, message);
            MessageBox.Show("E-mail envoyé !");
        }



        private void creerRdvEventHandle(object sender, EventArgs e)
        {
            DateTime date = this.nouveauRvView.date;
            string date1=date.ToShortDateString();
            string heure = this.nouveauRvView.heure;
            string typeRdv = this.NouveauRvView.typeRdv;
            UserDto user = bindingUser.Current as UserDto;
            rdvList = rendezVousService.listerRendezVous();
            int p=0;

            if (user.Role == Role.RP && typeRdv.CompareTo("Consultation") == 0)
            {
                MessageBox.Show("Impossible de créer un rendez-vous de type consultation pour le RP");
            }
            else if (user.Role == Role.Medecin && typeRdv.CompareTo("Prestation") == 0)
            {
                MessageBox.Show("Impossible de créer un rendez-vous de type prestation pour le Médecin");
            }
            else
            {
                
                RendezVous rendezVous = new RendezVous()
                {
                    Date = date.ToShortDateString(),
                    Heure = heure,
                    Patient = patient,
                    Type = typeRdv,
                    Traitant = user.toUser(),
                };

                foreach (RendezVous rdv in rdvList)
                {
                    DateTime dateRdv = DateTime.Parse(rdv.Date);
                    DateTime dateMedecin = DateTime.Parse(date1);

                    if ((rdv.Traitant.Id == user.Id) && (rdv.Heure == heure) && (dateRdv == dateMedecin))
                    {
                        MessageBox.Show("Impossible de créer un rendez-vous car ce Médecin ou " +
                            "ce RP est déja occupé à cette date et cette Heure");
                        p = 1;
                        break;

                    }
                }
                if (p != 1)
                {
                    rendezVousService.creerRendezVous(rendezVous);
                    MessageBox.Show("Rendez-vous créer avec succèes");
                    //
                    this.nouveauRvView.mail = true;
                }

               
            }

        }

        public INouveauRvView NouveauRvView { get => nouveauRvView; set => nouveauRvView = value; }
        public Patient Patient { get => patient; set => patient = value; }


    }
}

  
           
 

