﻿using Gestion_Rv.Services;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;
using System.Windows.Forms;
using Gestion_Rv.Models;
using System.Drawing.Text;

namespace Gestion_Rv.Presenter
{
    public class RendezVousPresenter : IRendezVousPresenter
    {
        //Couplage faible

        private IRendezVousView rendezVousView;
        private IRendezVousService rendezVousService;
        public RendezVousPresenter(IRendezVousView rendezVousView)
        {
            this.rendezVousView = rendezVousView;
            rendezVousService = FabriqueService.GetRendezVousService();
            //appel de la méthode Show() dans IRendezVousView pour afficher la page de rendez-vous
            this.rendezVousView.Show();
            //Appel de la méthode initialize dans le constructeur
            this.initialize();
            this.callbackEvent();

        }

        //BindingSource
        private BindingSource bindingRv = new BindingSource();

        //List
        /*Toutes les collections (Liste) implémentent l'interface*/
        IEnumerable<RendezVous> rvList = new List<RendezVous>();


        User user=ConnexionPresenter.user;
        private void initialize()
        {
            ShowRdvByUser();
            this.rendezVousView.setRendezVousBindingSource(bindingRv);
  
        }


        private void ShowRdvByUser()
        {
            //Récupération de la date du jour + Conversion en string 
            string date = DateTime.Now.ToShortDateString();

            if (user.Role == Role.Medecin)
            {
                //lister les rendezVous de la journée du medecin
                rvList = rendezVousService.listerRdvUnUser(date,user);
                bindingRv.DataSource = rvList;
                //
                this.rendezVousView.panelPrestation = false;


            }
            if(user.Role == Role.RP)
            {
                //lister les rendezVous de la journée de RP
                rvList = rendezVousService.listerRdvUnUser(date, user);
                bindingRv.DataSource = rvList;
                //
                this.rendezVousView.panelConsultation = false;
            }
            if (user.Role == Role.Secretaire)
            {
                //lister les rendezVous de la journée
                rvList = rendezVousService.listerRv(date);
                bindingRv.DataSource = rvList;
                //
                this.rendezVousView.panelConsultation = false;
                this.rendezVousView.panelPrestation= false;
            }
        }

        private void callbackEvent()
        {
            //Mapping => ecouteurs d'évènements
            this.rendezVousView.annulerRvEvent += annulerRvEventHandle;
            this.rendezVousView.filtreRvEvent += filtreRvEventhandle;
            this.rendezVousView.showFormNouvellePrestationEvent += showFormNouvellePrestationEventHandle;
            this.rendezVousView.showNouvelleConsultationEvent += showFormNouvelleConsultationEventHandle;
           
        }

  

        private void showFiltreRdvByDate(string date)
        {
            if (user.Role == Role.Medecin)
            {
                rvList = rendezVousService.listerRdvUnUser(date, user);
                bindingRv.DataSource = rvList;

            }
            else if (user.Role == Role.RP)
            {
                rvList = rendezVousService.listerRdvUnUser(date, user);
                bindingRv.DataSource = rvList;
            }
            else
            {
                rvList = rendezVousService.listerRv(date);
                bindingRv.DataSource = rvList;
            }
        }

        //Page pour une nouvelle prestation

        NouvellePrestationPresenter prestationPresenter = null;
        private void showFormNouvellePrestationEventHandle(object sender, EventArgs e)
        {
            RendezVous rdv = bindingRv.Current as RendezVous;
            if (rdv.Etat.CompareTo("Annuler") == 0)
            {
                MessageBox.Show("Impossible de sélectionner le rendez-vous car il a été annulé !");
            }
            else if (rdv.Etat.CompareTo("Terminer") == 0)
            {
                MessageBox.Show("Impossible de sélectionner ce rendez-vous car il a été déja abouti à une Prestation !");
            }
            else
            {
                //Fenêtre de Nouvelle Prestation
                if (prestationPresenter == null)
                {
                    prestationPresenter = new NouvellePrestationPresenter(rdv, new FormNouvellePrestation());
                }
                else
                {
                    prestationPresenter.Views = new FormNouvellePrestation();
                    prestationPresenter.Rdv = rdv;
                    prestationPresenter.initiliaze();
                    prestationPresenter.Views.Show();

                }
            }
        }

        //Page pour une nouvelle consultation

        NouvelleConsultationPresenter presenter = null;
        private void showFormNouvelleConsultationEventHandle(object sender, EventArgs e)
        {
            RendezVous rdv = bindingRv.Current as RendezVous;
            if (rdv.Etat.CompareTo("Annuler") == 0 )
            {
                MessageBox.Show("Impossible de sélectionner ce rendez-vous car il a été annulé !");
            }
            else if(rdv.Etat.CompareTo("Terminer") == 0)
            {
                MessageBox.Show("Impossible de sélectionner ce rendez-vous car il a été déja abouti à une consultation !");
            }
            else
            {
                //Fenêtre de Nouvelle Consultation
                if (presenter == null)
                {
                    presenter = new NouvelleConsultationPresenter(rdv, new FormNouvelleConsultation());
                }
                else
                {
                    presenter.Views = new FormNouvelleConsultation();
                    presenter.Rdv = rdv;
                    presenter.initialize();
                    presenter.Views.Show();
                }
            }
           
        }


        //Méthode pour filtrer la liste des rendezVous par date
        private void filtreRvEventhandle(object sender, EventArgs e)
        {
            //Récupération de la date séléctionnée dans le dateTimePicker
            DateTime date = this.rendezVousView.listDate;
            var btn = sender as Button;
            if (btn.Name == "btnFiltre")
            {
                showFiltreRdvByDate(date.ToShortDateString());
            }
            if (btn.Name == "btnAll")
            {
                showFiltreRdvByDate(DateTime.Now.ToShortDateString());
        
            }

        }

       
        private void annulerRvEventHandle(object sender, EventArgs e)
        {
            DateTime date = this.rendezVousView.listDate;
            RendezVous rv=bindingRv.Current as RendezVous;
            rv.Etat = "Annuler";
            try
            {
                rendezVousService.annulerRdv(rv);
            }
            catch (Exception)
            {

                throw;
            }
            //Comparaison de la date du jour et de la date du combo dateTimePicker
            //Si la date selectionnée dans le dateTimePicker diffère de la date du jour
            //alors l'utlisateur cherche à afficher la liste des rendez Vous  par date
            if (date.ToShortDateString() != DateTime.Now.ToShortDateString())
            {
                showFiltreRdvByDate(date.ToShortDateString());
            }
            else
            {
                showFiltreRdvByDate(DateTime.Now.ToShortDateString());
            }

        }

    }
}
