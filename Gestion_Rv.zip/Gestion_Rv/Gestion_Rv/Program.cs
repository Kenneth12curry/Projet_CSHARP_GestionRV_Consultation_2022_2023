﻿using Gestion_Rv.Presenter;
using Gestion_Rv.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv
{
    internal static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //Création d'un objet de type formconnexion à travers l'interface IConnexionView
            IConnexionView view = new FormConnexion();
            IConnexionPresenter ConnexionPresenter = new ConnexionPresenter(view);
            //IPlanningViews view=new FormPlanningViews();
            //IPlanningPresenter planningPresenter = new PlanningPresenter(view);
            Application.Run(view as FormConnexion);
        }
    }
}
