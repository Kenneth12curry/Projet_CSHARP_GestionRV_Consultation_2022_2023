﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public class BaseRepository
    {
        public string connectionString;
        public string ConnectionString { get => connectionString; set => connectionString = value; }
    }
}
