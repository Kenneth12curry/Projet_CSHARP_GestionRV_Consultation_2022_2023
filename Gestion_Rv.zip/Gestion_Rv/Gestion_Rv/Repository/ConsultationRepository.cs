﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public class ConsultationRepository : BaseRepository, IConsultationRepository
    {

        private readonly string SQL_INSERT = @"insert into consultations(date,temperature,tension,poids,motif,patient_id,medecin_id,idRdv) values (@date,@temperature,@tension,@poids,@motif,@patient_id,@medecin_id,@idRdv)";
        private readonly string SQL_SELECT_CONSULTATIONS_PATIENTS = @"select c.* from consultations c where c.patient_id=@patientId";
        private readonly string SQL_CONSULTATIONS_BY_DATE = @"select * from consultations where date=@date";
        private readonly string SQL_SELECT_CONSULTATIONS_MEDECINS = "select * from consultations where date=@date and medecin_id=@medecin_id";
        private readonly string SQL_SELECT_ID = "select * from consultations where id=@id";

        private IPatientRepository patientRepository;
        private IMedecinRepository medecinRepository;

        public ConsultationRepository(string connectionString, IPatientRepository patientRepository, IMedecinRepository medecinRepository)
        {
            ConnectionString = connectionString;
            this.patientRepository = patientRepository;
            this.medecinRepository = medecinRepository;

        }


        public List<Consultation> findAll()
        {
            throw new NotImplementedException();
        }

        public void insert(Consultation consultation)
        {
            //1-Ouvrir la connexion
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_INSERT;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = consultation.Date;
                    command.Parameters.Add("@temperature", SqlDbType.NVarChar).Value = consultation.Temperature;
                    command.Parameters.Add("@tension", SqlDbType.NVarChar).Value = consultation.Tension;
                    command.Parameters.Add("@poids", SqlDbType.NVarChar).Value = consultation.Poids;
                    command.Parameters.Add("@motif", SqlDbType.NVarChar).Value = consultation.Motif;
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = consultation.Patient.Id;
                    command.Parameters.Add("@medecin_id", SqlDbType.Int).Value = consultation.Medecin.Id;
                    command.Parameters.Add("@idRdv", SqlDbType.Int).Value = consultation.Rdv.Id;
                    //3-Exécute la requête et la récupération des données
                    command.ExecuteNonQuery();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }

            };
        }

        public List<Consultation> findConsultationsUnPatient(Patient patient)
        {
            List<Consultation> consultations = new List<Consultation>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_CONSULTATIONS_PATIENTS;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@patientId", SqlDbType.Int).Value = patient.Id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        Consultation consultation = new Consultation()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Temperature = dr[2].ToString(),
                            Tension = dr[3].ToString(),
                            Poids = dr[4].ToString(),
                            Motif = dr[5].ToString(),
                            Patient = patientRepository.findById((int)dr[6]),
                            Medecin = medecinRepository.findById((int)dr[7]),
                        };

                        consultations.Add(consultation);

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return consultations;

            };
        }

        public List<ConsultationDto> findByConsultationParDate(string date)
        {
            List<ConsultationDto> consultations = new List<ConsultationDto>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_CONSULTATIONS_BY_DATE;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        ConsultationDto consultation = new ConsultationDto()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            /*Temperature = dr[2].ToString(),
                            Tension = dr[3].ToString(),
                            Poids = dr[4].ToString(),
                            Motif = dr[5].ToString(),*/
                            Patient = patientRepository.findById((int)dr[6]),
                            Medecin = medecinRepository.findById((int)dr[7]),
                        };

                        consultations.Add(consultation);

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return consultations;
            }
        }

        public List<ConsultationDto> findConsultation(string date, User user)
        {
            List<ConsultationDto> consultations = new List<ConsultationDto>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_CONSULTATIONS_MEDECINS;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    command.Parameters.Add("@medecin_id", SqlDbType.Int).Value = user.Id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        ConsultationDto consultation = new ConsultationDto()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            /*Temperature = dr[2].ToString(),
                            Tension = dr[3].ToString(),
                            Poids = dr[4].ToString(),
                            Motif = dr[5].ToString(),*/
                            Patient = patientRepository.findById((int)dr[6]),
                            Medecin = medecinRepository.findById((int)dr[7]),
                        };

                        consultations.Add(consultation);

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return consultations;
            }
        }

        public List<ConsultationDto> findConsultationsPatient(Patient patient)
        {
            List<ConsultationDto> consultations = new List<ConsultationDto>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_CONSULTATIONS_PATIENTS;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@patientId", SqlDbType.Int).Value = patient.Id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        ConsultationDto consultation = new ConsultationDto()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            /*Temperature = dr[2].ToString(),
                            Tension = dr[3].ToString(),
                            Poids = dr[4].ToString(),
                            Motif = dr[5].ToString(),*/
                            Patient = patientRepository.findById((int)dr[6]),
                            Medecin = medecinRepository.findById((int)dr[7]),
                        };

                        consultations.Add(consultation);

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return consultations;

            };
        }

        public Consultation findById(int id)
        {
            Consultation consultation= null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_ID;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        consultation = new Consultation()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Temperature = dr[2].ToString(),
                            Tension = dr[3].ToString(),
                            Poids = dr[4].ToString(),
                            Motif = dr[5].ToString(),
                            Patient = patientRepository.findById((int)dr[6]),
                            Medecin = medecinRepository.findById((int)dr[7]),
                        };

                      
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return consultation;
            }
        }
    }
}

