﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public interface IConsultationRepository:IRepository<Consultation>
    {

        List<ConsultationDto> findConsultation(string date,User user);
        List<Consultation> findConsultationsUnPatient(Patient patient);
        List<ConsultationDto> findConsultationsPatient(Patient patient);
        List<ConsultationDto> findByConsultationParDate(string date);
        Consultation findById(int id);

    }
}
