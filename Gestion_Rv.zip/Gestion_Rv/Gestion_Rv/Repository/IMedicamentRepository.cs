﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public interface IMedicamentRepository:IRepository<Medicament>
    {
        List<Medicament> findAll(Ordonnance ordonnance);

        Medicament findByCode(string code);
    }
}
