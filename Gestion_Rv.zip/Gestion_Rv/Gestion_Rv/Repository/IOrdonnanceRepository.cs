﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public interface IOrdonnanceRepository:IRepository<Ordonnance>
    {
        Ordonnance findByNumero(string numero);
        Ordonnance findById(int id);
        Ordonnance insert_ordonnance(Ordonnance ordonnance);
        List<Ordonnance> findAll(Patient patient);
    }
}
