﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public  interface IPlanningRepository:IRepository<Planning>
    {
        List<Planning> findAll(User user);
        Planning findByPlanning(User user,string jour , string horaireDebut, string horaireFin);
    }
}
