﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public interface IPrestationRepository:IRepository<Prestation>
    {
      
        List<PrestationDto> findPrestations(string date,User user);
        List<PrestationDto> findPrestationsUnPatient(Patient patient);
        List<PrestationDto> findPrestationsParDate(string date);

    }
}
