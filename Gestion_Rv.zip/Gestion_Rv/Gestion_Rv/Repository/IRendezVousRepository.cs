﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public interface IRendezVousRepository:IRepository<RendezVous>
    {
       List<RendezVous> findAll(string date);
       List<RendezVous> findRdvByUser(string date,User user);
        RendezVous findrdv(string heure, string date, User user);


    }
}
