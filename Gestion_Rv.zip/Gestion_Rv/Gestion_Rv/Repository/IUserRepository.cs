﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public interface IUserRepository:IRepository<User>
    {
      
        User findByLogin(string login);
        List<UserDto> finduser(string role1,string type);
        List<UserDto> findUserByRole(string role1);
        List<UserDto> findAll(string jour);
        User findById(int id);
        RP findByIdRP(int id);
       
    }
}
