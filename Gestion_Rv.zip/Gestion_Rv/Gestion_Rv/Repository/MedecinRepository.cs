﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public class MedecinRepository :BaseRepository, IMedecinRepository
    {
        private readonly string SQL_SELECT = "select * from users where role like 'Medecin'";
        private readonly string SQL_SELECT_ID = "select * from users where role like 'Medecin' and id=@id";
       

        public MedecinRepository(string connectionString)
        {
            ConnectionString= connectionString;
        }

        public List<Medecin> findAll()
        {
            List<Medecin> medecins = new List<Medecin>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    while (dr.Read())
                    {

                        //Mappping Relationnel vers Objet
                        Medecin medecin = new Medecin()
                        {
                            Id = (int)dr[0],
                            Login = dr[1].ToString(),
                            Password = dr[2].ToString(),
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString()

                        };
                        Enum.TryParse(dr[5].ToString(), out Role role);
                        medecin.Role = role;
                        Enum.TryParse(dr[7].ToString(), out TypeM type);
                        medecin.Type = type;
                        medecins.Add(medecin);

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return medecins;

            }

        }

        public Medecin findById(int id)
        {
            Medecin medecin= null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_ID;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        medecin = new Medecin()
                        {
                            Id = (int)dr[0],
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString(),
                        };
                        Enum.TryParse(dr[5].ToString(), out Role role);
                        medecin.Role = role;
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return medecin;
            }
        }

       
 

        public void insert(Medecin obj)
        {
            throw new NotImplementedException();
        }
    }
}
