﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gestion_Rv.Dto;

namespace Gestion_Rv.Repository
{
    public class MedicamentRepository : BaseRepository, IMedicamentRepository
    {
        private readonly string SELECT_CODE = @"select * from medicaments where code=@code";
        private readonly string SQL_INSERT = @"insert into medicaments(code,nom,posologie,ordonnance_id) values(@code,@nom,@posologie,@ordonnance_id)";
        private readonly string SQL_SELECT = @"select * from medicaments where ordonnance_id=@ordonnance_id";

        private IOrdonnanceRepository ordonnanceRepository;

        public MedicamentRepository(string connectionString,IOrdonnanceRepository ordonnanceRepository)
        {
            ConnectionString =  connectionString;
            this.ordonnanceRepository= ordonnanceRepository;
        }


        public List<Medicament> findAll(Ordonnance ordonnance)
        {
            List<Medicament> medicaments = new List<Medicament>();
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@ordonnance_id", SqlDbType.NVarChar).Value = ordonnance.Id;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        Medicament medicament = new Medicament()
                        {
                            Id = (int)dr[0],
                            Code = dr[1].ToString(),
                            Nom = dr[2].ToString(),
                            Posologie = dr[3].ToString(),

                        };
                        medicaments.Add(medicament);

                    }
                    dr.Close();
                    

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return medicaments;
            };
        }


        public List<Medicament> findAll()
        {
            throw new NotImplementedException();
        }

        public Medicament findByCode(string code)
        {
            Medicament medicament = null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SELECT_CODE;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@code", SqlDbType.NVarChar).Value = code;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        medicament = new Medicament()
                        {
                            Id = (int)dr[0],
                            Code = dr[1].ToString(),
                            Nom = dr[2].ToString(),
                            Posologie = dr[3].ToString(),

                        };


                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return medicament;
            };
        }

        public void insert(Medicament medicament)
        {
            //1-Ouvrir la connexion
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_INSERT;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@code", SqlDbType.NVarChar).Value = medicament.Code;
                    command.Parameters.Add("@nom", SqlDbType.NVarChar).Value = medicament.Nom;
                    command.Parameters.Add("@posologie", SqlDbType.NVarChar).Value = medicament.Posologie;
                    command.Parameters.Add("@ordonnance_id", SqlDbType.Int).Value = medicament.Ordonnance.Id;
                    //3-Exécute la requête et la récupération des données
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                }
            }

        }
    }
}
