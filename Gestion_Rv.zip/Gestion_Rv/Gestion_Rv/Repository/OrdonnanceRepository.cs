﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public class OrdonnanceRepository : BaseRepository, IOrdonnanceRepository
    {
        private readonly string SQL_INSERT = @"insert into ordonnance(libelle,patient_id) output INSERTED.idOrdonnance values(@libelle,@patient_id)";
        private readonly string SQL_SELECT_NUMERO = @"select * from ordonnance where libelle like '%'+@libelle+'%'";
        private readonly string SQL_SELECT = @"select * from ordonnance where patient_id=@patient_id";
        private readonly string SELECT = "select * from ordonnance";
        private readonly string SQL_SELECT_ID = @"select * from ordonnance where id=@id";

        private IPatientRepository patientRepository;
        public OrdonnanceRepository(string connectionstring,IPatientRepository patientRepository)
        {
            ConnectionString = connectionstring;
            this.patientRepository = patientRepository;
        }

        public List<Ordonnance> findAll()
        {

            List<Ordonnance> ordonnances = new List<Ordonnance>();
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SELECT;
                    //3-Changer les paramètres par les valeurs
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        Ordonnance ordonnance = new Ordonnance()
                        {
                            Id = (int)dr[0],
                            Libelle = dr[1].ToString(),
                            Patient = patientRepository.findById((int)dr[2])

                        };
                        ordonnances.Add(ordonnance);
                    }
                    dr.Close();
                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return ordonnances;
            };
        }


        public void insert(Ordonnance ordonnance)
        {
            throw new NotImplementedException();
        }

        public Ordonnance findByNumero(string numero)
        {
            Ordonnance ordonnance = null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_NUMERO;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@libelle", SqlDbType.NVarChar).Value = numero;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        ordonnance = new Ordonnance()
                        {
                            Id = (int)dr[0],
                            Libelle = dr[1].ToString(),

                        };

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return ordonnance;
            }
        }

        public Ordonnance insert_ordonnance(Ordonnance ordonnance)
        {
            //1-Ouvrir la connexion
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_INSERT;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@libelle", SqlDbType.NVarChar).Value = ordonnance.Libelle;
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = ordonnance.Patient.Id;
                    //3-Exécute la requête et la récupération des données
                    int id=(int)command.ExecuteScalar();
                    ordonnance.Id= id;
                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
             return ordonnance;

            }
        }

        public List<Ordonnance> findAll(Patient patient)
        {
            List<Ordonnance> ordonnances=new List<Ordonnance>();
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = patient.Id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while(dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        Ordonnance ordonnance = new Ordonnance()
                        {
                            Id = (int)dr[0],
                            Libelle = dr[1].ToString(),
                            Patient= patientRepository.findById((int)dr[2])

                        };
                        ordonnances.Add(ordonnance);
                    }
                    dr.Close();
                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return ordonnances;
            };
        }

        public Ordonnance findById(int id)
        {
            Ordonnance ordonnance = null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_ID;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        ordonnance = new Ordonnance()
                        {
                            Id = (int)dr[0],
                            Libelle = dr[1].ToString(),

                        };

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return ordonnance;
            }
        }
    }
}