﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Repository
{
    public class PatientRepository:BaseRepository,IPatientRepository
    {

        private readonly string SQL_INSERT = @"insert into users(nom,prenom,role,code,email,tel) values(@nom,@prenom,@role,@code,@email,@tel)";
        private readonly string SQL_SELECT = "select * from users where role like 'Patient'";
        private readonly string SQL_SELECT_TEL = "select * from users where role like 'Patient' and tel like '%'+@tel+'%'";
        private readonly string SQL_SELECT_BYID = @"select * from users u where role like 'Patient' and u.id=@id";

        public PatientRepository(string connectionString)
        {
            ConnectionString = connectionString;
            
        }

        public List<PatientDto> findAll()
        {
            List<PatientDto> patients = new List<PatientDto>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        PatientDto patient = new PatientDto()
                        {
                            Id = (int)dr[0],
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString(),
                            Code = dr[6].ToString(),
                            Email = dr[7].ToString(),
                            Tel = dr[8].ToString(),
                        };

                        Enum.TryParse(dr[5].ToString(), out RolePatient role);
                        patient.Role1 = role;
                        patients.Add(patient);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return patients;

            }
        }



        public Patient persist(Patient patient)
        {
            //1-Ouvrir la connexion
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_INSERT;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@nom", SqlDbType.NVarChar).Value = patient.Nom;
                    command.Parameters.Add("@prenom", SqlDbType.NVarChar).Value = patient.Prenom;
                    command.Parameters.Add("@role", SqlDbType.NVarChar).Value = patient.Role;
                    command.Parameters.Add("@code", SqlDbType.NVarChar).Value = patient.Code;
                    command.Parameters.Add("@email", SqlDbType.NVarChar).Value = patient.Email;
                    command.Parameters.Add("@tel", SqlDbType.NVarChar).Value = patient.Tel;
                    //3-Exécute la requête et la récupération des données
                    command.ExecuteNonQuery();


                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return patient;
            };
        }

        public PatientDto findByTel(string tel)
        {
            PatientDto patient = null;

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_TEL;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@tel", SqlDbType.NVarChar).Value = tel;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        patient = new PatientDto()
                        {
                            Id = (int)dr[0],
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString(),
                            Code = dr[6].ToString(),
                            Email = dr[7].ToString(),
                            Tel = dr[8].ToString(),
                        };

                        Enum.TryParse(dr[5].ToString(), out RolePatient role);
                        patient.Role1 = role;
                       

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return patient;

            };
        }

        public  Patient findById(int id)
        {
            Patient patient = null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_BYID;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@id", SqlDbType.NVarChar).Value = id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                         patient = new Patient()
                        {
                            Id = (int)dr[0],
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString(),
                            Code = dr[6].ToString(),
                            Email = dr[7].ToString(),
                            Tel = dr[8].ToString(),
                         };
                        Enum.TryParse(dr[5].ToString(), out Role role);
                        patient.Role = role;

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return patient;

            }
        }

        
    }
}
