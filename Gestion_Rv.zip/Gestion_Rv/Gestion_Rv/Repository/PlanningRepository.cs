﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Gestion_Rv.Dto;

namespace Gestion_Rv.Repository
{
    public class PlanningRepository : BaseRepository, IPlanningRepository
    {
        private readonly string SQL_INSERT= @"insert into planning(jour,horaireDebut,horaireFin,user_id) values (@jour,@horaireDebut,@horaireFin,@user_id)";
        private readonly string SQL_SELECT = @"select * from planning where user_id=@user_id";
        private readonly string SQL_SELECT_PLANNING = "select * from planning where  user_id=@user_id and jour like '%'+@jour+'%' and horaireDebut like '%'+@horaireDebut+'%' and horaireFin like '%'+@horaireFin+'%'";

        private IUserRepository userRepository;

        public PlanningRepository(string connectionString,IUserRepository userRepository)
        {
            ConnectionString = connectionString;
            this.userRepository = userRepository;
        }

        public List<Planning> findAll()
        {
            throw new NotImplementedException();
        }

        public List<Planning> findAll(User user)
        {

            List<Planning> plannings = new List<Planning>();
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@user_id", SqlDbType.Int).Value = user.Id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        Planning planing = new Planning()
                        {
                            Id = (int)dr[0],
                            Jour = dr[1].ToString(),
                            HoraireDebut = dr[2].ToString(),
                            HoraireFin = dr[3].ToString(),
                            User = userRepository.findById((int)dr[4])

                        };
                        plannings.Add(planing);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return plannings;
            };
           
        }

        public Planning findByPlanning(User user, string jour, string horaireDebut, string horaireFin)
        {
            Planning planning=null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_PLANNING;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@user_id", SqlDbType.Int).Value = user.Id;
                    command.Parameters.Add("@jour", SqlDbType.NVarChar).Value = jour;
                    command.Parameters.Add("@horaireDebut", SqlDbType.NVarChar).Value = horaireDebut;
                    command.Parameters.Add("@horaireFin", SqlDbType.NVarChar).Value = horaireFin;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        planning = new Planning()
                        {
                            Id = (int)dr[0],
                            Jour = dr[1].ToString(),
                            HoraireDebut = dr[2].ToString(),
                            HoraireFin = dr[3].ToString(),


                        };
                       
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return planning;
            }; ;
        }

        public void insert(Planning planning)
        {
            //1-Ouvrir la connexion
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_INSERT;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@jour", SqlDbType.NVarChar).Value = planning.Jour;
                    command.Parameters.Add("@horaireDebut", SqlDbType.NVarChar).Value = planning.HoraireDebut;
                    command.Parameters.Add("@horaireFin", SqlDbType.NVarChar).Value = planning.HoraireFin;
                    command.Parameters.Add("@user_id", SqlDbType.Int).Value = planning.User.Id;

                    //3-Exécute la requête et la récupération des données
                    command.ExecuteNonQuery();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }

            };
        }
    }
}
