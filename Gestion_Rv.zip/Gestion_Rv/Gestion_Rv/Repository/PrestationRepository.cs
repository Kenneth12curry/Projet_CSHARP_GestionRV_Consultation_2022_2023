﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public class PrestationRepository : BaseRepository, IPrestationRepository
    {
      
        private readonly string SQL_INSERT = @"insert into prestations(date,typePrestation,patient_id,RP_id,idRdv) values (@date,@typePrestation,@patient_id,@RP_id,@idRdv)";
        private readonly string SQL_SELECT_PRESTATIONS = @"select p.* from prestations p where p.patient_id=@patientId";
        private readonly string SQL_PRESTATIONS_BY_DATE = @"select * from prestations where date=@date";
        private readonly string SQL_SELECT_PRESTATIONS_RP = @"select * from prestations p where date=@date and p.RP_id=@id";

        private IPatientRepository patientRepository;
        private IUserRepository userRepository;
        public PrestationRepository(string connectionString, IPatientRepository patientRepository,IUserRepository userRepository)
        {
            ConnectionString = connectionString;
            this.patientRepository = patientRepository;
            this.userRepository= userRepository;
        }

        

        public void insert(Prestation prestation)
        {
            //1-Ouvrir la connexion
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_INSERT;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.DateTime).Value = prestation.Date;
                    command.Parameters.Add("@typePrestation", SqlDbType.NVarChar).Value = prestation.Type;
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = prestation.Patient.Id;
                    command.Parameters.Add("@RP_id", SqlDbType.Int).Value = prestation.Rp.Id;
                    command.Parameters.Add("@idRdv", SqlDbType.Int).Value = prestation.Rdv.Id;
                    //3-Exécute la requête et la récupération des données
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }

            }; 
        }

        public List<PrestationDto> findPrestationsUnPatient(Patient patient)
        {
            List<PrestationDto> prestations = new List<PrestationDto>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_PRESTATIONS;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@patientId", SqlDbType.Int).Value = patient.Id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        PrestationDto prestation = new PrestationDto()
                        {
                            Id = (int)dr[0],
                            Date = dr[2].ToString(),
                            Type = dr[1].ToString(),
                            Patient = patientRepository.findById((int)dr[3]),
                            Rp = userRepository.findByIdRP((int)dr[4])


                        };
                        prestations.Add(prestation);

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return prestations;

            };
        }

        public List<PrestationDto> findPrestationsParDate(string date)
        {
            List<PrestationDto> prestations = new List<PrestationDto>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_PRESTATIONS_BY_DATE;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        PrestationDto prestation = new PrestationDto
                            ()
                        {
                            Id = (int)dr[0],
                            Date = dr[2].ToString(),
                            Type = dr[1].ToString(),
                            Patient = patientRepository.findById((int)dr[3]),
                            Rp = userRepository.findByIdRP((int)dr[4])

                        };
                        prestations.Add(prestation);

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return prestations;

            };
        }

        public List<Prestation> findAll()
        {
            throw new NotImplementedException();
        }

        public List<PrestationDto> findPrestations(string date,User user)
        {
            List<PrestationDto> prestations = new List<PrestationDto>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_PRESTATIONS_RP;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    command.Parameters.Add("@Id", SqlDbType.Int).Value = user.Id;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {

                        //Mappping Relationnel vers Objet
                        PrestationDto prestation = new PrestationDto()
                        {
                            Id = (int)dr[0],
                            Date = dr[2].ToString(),
                            Type = dr[1].ToString(),
                            Patient = patientRepository.findById((int)dr[3]),
                            Rp = userRepository.findByIdRP((int)dr[4])


                        };
                        prestations.Add(prestation);

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return prestations;

            };
        }
    }
}
