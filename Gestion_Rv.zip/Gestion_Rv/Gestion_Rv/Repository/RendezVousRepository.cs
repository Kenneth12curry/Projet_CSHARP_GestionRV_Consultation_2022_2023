﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing.Text;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace Gestion_Rv.Repository
{
    public class RendezVousRepository : BaseRepository, IRendezVousRepository
    {
        private readonly string SQL_SELECT_ALL = "select * from rendezvous";
        private readonly string SQL_SELECT = "select * from rendezvous where date=@date";
        private readonly string SQL_INSERT = @"insert into rendezvous(date,heure,etat,typeRdv,patient_id,user_id) values(@date,@heure,@etat,@type,@patient_id,@user_id)";
        private readonly string SQL_UPDATE = "UPDATE rendezvous set etat=@etat1 WHERE id=@id";
        private readonly string SQL_FILTRE_DATE_MEDECIN = @"select * from rendezvous r where r.date=@date and r.user_id=@userId";
        private readonly string SELECT_RDV = "select r.* from rendezvous r,users u where r.user_id=u.id and r.heure=@heure and r.date=@date and u.id=@id";

        private IPatientRepository patientRepository;
        private IUserRepository userRepository;

        public RendezVousRepository(string connectionString, IPatientRepository patientRepository, IUserRepository userRepository)
        {
            ConnectionString = connectionString;
            this.patientRepository = patientRepository;
            this.userRepository= userRepository;

        }

        public List<RendezVous> findAll(string date)
        {
            List<RendezVous> Rv = new List<RendezVous>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        int id = (int)dr[5];
                        //Mappping Relationnel vers Objet
                        RendezVous rv = new RendezVous()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Heure = dr[2].ToString(),
                            Etat = dr[3].ToString(),
                            Type = dr[4].ToString(),
                            Patient = patientRepository.findById(id),
                            Traitant = userRepository.findById((int)dr[6])


                        };
                        Rv.Add(rv);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return Rv;

            }
        }

        public void insert(RendezVous rv)
        {
            //1-Ouvrir la connexion
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    if (rv.Id != 0)
                    {
                        command.CommandText = SQL_UPDATE;
                        command.Parameters.Add("@etat1", SqlDbType.NVarChar).Value = rv.Etat;
                        command.Parameters.Add("@id", SqlDbType.Int).Value = rv.Id;
                    }
                    else
                    {
                        command.CommandText = SQL_INSERT;
                    }

                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = rv.Date;
                    command.Parameters.Add("@heure", SqlDbType.NVarChar).Value = rv.Heure;
                    command.Parameters.Add("@etat", SqlDbType.NVarChar).Value = rv.Etat;
                    command.Parameters.Add("@type", SqlDbType.NVarChar).Value = rv.Type;
                    command.Parameters.Add("@patient_id", SqlDbType.Int).Value = rv.Patient.Id;
                    command.Parameters.Add("@user_id", SqlDbType.Int).Value = rv.Traitant.Id;
                    //3-Exécute la requête et la récupération des données
                    command.ExecuteNonQuery();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }

            };
        }

       
        public List<RendezVous> findRdvByUser(string date, User user)
        {

            List<RendezVous> Rv = new List<RendezVous>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_FILTRE_DATE_MEDECIN;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    command.Parameters.Add("@userId", SqlDbType.Int).Value = user.Id;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet

                        RendezVous rv = new RendezVous()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Heure = dr[2].ToString(),
                            Etat = dr[3].ToString(),
                            Type = dr[4].ToString(),
                            Patient = patientRepository.findById((int)dr[5]),
                            Traitant= userRepository.findById((int)dr[6])   

                        };
                        Rv.Add(rv);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return Rv;
            }
        }

        public List<RendezVous> findAll()
        {
            List<RendezVous> Rv = new List<RendezVous>();

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_ALL;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        int id = (int)dr[5];
                        //Mappping Relationnel vers Objet
                        RendezVous rv = new RendezVous()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Heure = dr[2].ToString(),
                            Etat = dr[3].ToString(),
                            Type = dr[4].ToString(),
                            Patient = patientRepository.findById(id),
                            Traitant = userRepository.findById((int)dr[6])


                        };
                        Rv.Add(rv);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return Rv;

            }
        }

        public RendezVous findrdv(string heure, string date, User user)
        {
            RendezVous Rdv = null;

            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SELECT_RDV;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@date", SqlDbType.Date).Value = date;
                    command.Parameters.Add("@heure", SqlDbType.NVarChar).Value = heure;
                    command.Parameters.Add("@id", SqlDbType.Int).Value = user.Id;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet

                        RendezVous rv = new RendezVous()
                        {
                            Id = (int)dr[0],
                            Date = dr[1].ToString(),
                            Heure = dr[2].ToString(),
                            Etat = dr[3].ToString(),
                            Type = dr[4].ToString(),
                            Patient = patientRepository.findById((int)dr[5]),
                            Traitant = userRepository.findById((int)dr[6])

                        };

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return Rdv;
            }
        }
    }
}

