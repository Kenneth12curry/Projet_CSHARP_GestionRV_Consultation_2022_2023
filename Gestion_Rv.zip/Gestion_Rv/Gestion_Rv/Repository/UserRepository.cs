﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using Gestion_Rv.Dto;

namespace Gestion_Rv.Repository
{
    public class UserRepository : BaseRepository, IUserRepository
    {

        private readonly string SQL_SELECT_BY_LOGIN = @"select * from users where login like '%'+@login+'%'";
        private readonly string SQL_SELECT = @"select * from users where role=@role and type_medecin=@type_medecin";
        private readonly string SQL_USER_JOUR = "select u.* from users u,planning p where u.id=p.user_id and p.jour=@jour";
        private readonly string SQL_SELECT_ID = @"select * from users where id=@id";
        private readonly string SQL_SELECT_ROLE = @"select * from users where role=@role";


        public UserRepository(string connectionString)
        {
            ConnectionString = connectionString;
        }

        
        public List<UserDto> findAll(string jour)
        {
            List<UserDto> users = new List<UserDto>();
            List<Planning> plannings = new List<Planning>();
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_USER_JOUR;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@jour", SqlDbType.NVarChar).Value = jour;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select)
                    while (dr.Read())
                    {
                        UserDto user = new UserDto()
                        {
                            Id = (int)dr[0],
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString(),

                        };

                        //Mappping Relationnel vers Objet
                        Enum.TryParse(dr[5].ToString(), out Role role);
                        user.Role = role;
                        users.Add(user);
                        
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                
                return users;
            }

        }

        public List<User> findAll()
        {
            throw new NotImplementedException();
        }

        public User findById(int id)
        {
            User user = null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_ID;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        user = new User()
                        {
                            Id = (int)dr[0],
                            Login = dr[1].ToString(),
                            Password = dr[2].ToString(),
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString(),

                        };
                        Enum.TryParse(dr[5].ToString(), out Role role);
                        user.Role = role;

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return user;
            }
        }

        public RP findByIdRP(int id)
        {
            RP rp = null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_ID;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@id", SqlDbType.Int).Value = id;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        rp = new RP()
                        {
                            Id = (int)dr[0],
                            Login = dr[1].ToString(),
                            Password = dr[2].ToString(),
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString(),

                        };
                        Enum.TryParse(dr[5].ToString(), out Role role);
                        rp.Role = role;

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return rp;
            }
        }

        public User findByLogin(string login)
        {
            User user = null;
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_BY_LOGIN;
                    //Changer les paramètres par les valeurs
                    command.Parameters.Add("@login", SqlDbType.NVarChar).Value = login;
                    //3-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //4-Parcours de Requête (select) => 
                    if (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        user = new User()
                        {
                            Id = (int)dr[0],
                            Login = dr[1].ToString(),
                            Password = dr[2].ToString(),
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString(),

                        };
                        Enum.TryParse(dr[5].ToString(), out Role role);
                        user.Role = role;

                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return user;

            }
        }

    public List<UserDto> finduser(string role1,string type)
    {
        List<UserDto> users = new List<UserDto>();
        using (var connection = new SqlConnection(ConnectionString))
        using (var command = new SqlCommand())
        {
            try
            {
                //1-Ouvrir la connexion
                connection.Open();
                command.Connection = connection;
                //2-prépare la requête
                command.CommandText = SQL_SELECT;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@role", SqlDbType.NVarChar).Value = role1;
                    command.Parameters.Add("@type_medecin", SqlDbType.NVarChar).Value = type;
                //4-Exécute la requête et la récupération des données
                SqlDataReader dr = command.ExecuteReader();
                //5-Parcours de Requête (select) => 
                while (dr.Read())
                {
                    //Mappping Relationnel vers Objet
                    UserDto user = new UserDto()
                    {
                        Id = (int)dr[0],
                        //Login = dr[1].ToString(),
                        //Password = dr[2].ToString(),
                        Nom = dr[3].ToString(),
                        Prenom = dr[4].ToString(),

                    };
                    Enum.TryParse(dr[5].ToString(), out Role role);
                    user.Role = role;
                    users.Add(user);
                }
                dr.Close();

            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                command.Dispose();
                //5-Fermer la connexion
                connection.Close();
            }
            return users; ;
           }

        }

        public List<UserDto> findUserByRole(string role1)
        {
            List<UserDto> users = new List<UserDto>();
            using (var connection = new SqlConnection(ConnectionString))
            using (var command = new SqlCommand())
            {
                try
                {
                    //1-Ouvrir la connexion
                    connection.Open();
                    command.Connection = connection;
                    //2-prépare la requête
                    command.CommandText = SQL_SELECT_ROLE;
                    //3-Changer les paramètres par les valeurs
                    command.Parameters.Add("@role", SqlDbType.NVarChar).Value = role1;
                    //4-Exécute la requête et la récupération des données
                    SqlDataReader dr = command.ExecuteReader();
                    //5-Parcours de Requête (select) => 
                    while (dr.Read())
                    {
                        //Mappping Relationnel vers Objet
                        UserDto user = new UserDto()
                        {
                            Id = (int)dr[0],
                            //Login = dr[1].ToString(),
                            //Password = dr[2].ToString(),
                            Nom = dr[3].ToString(),
                            Prenom = dr[4].ToString(),

                        };
                        Enum.TryParse(dr[5].ToString(), out Role role);
                        user.Role = role;
                        users.Add(user);
                    }
                    dr.Close();

                }
                catch (Exception ex)
                {

                    throw ex;
                }
                finally
                {
                    command.Dispose();
                    //5-Fermer la connexion
                    connection.Close();
                }
                return users; ;
            }
        }

        public void insert(User obj)
        {
            throw new NotImplementedException();
        }
    }
}
    

