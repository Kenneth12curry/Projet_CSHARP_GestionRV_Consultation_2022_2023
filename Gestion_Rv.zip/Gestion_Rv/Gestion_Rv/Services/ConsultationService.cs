﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public class ConsultationService:IConsultationService
    {
        private IConsultationRepository consultationRepository;

        public ConsultationService(IConsultationRepository consultationRepository)
        {
            this.consultationRepository = consultationRepository;
        }

        public void enregistrerConsultation(Consultation consultation)
        {
            consultationRepository.insert(consultation);
        }

        public List<ConsultationDto> findConsultationsPatients(Patient patient)
        {
            return consultationRepository.findConsultationsPatient(patient);
        }

        public List<ConsultationDto> listerConsultationMedecin(string date,User user)
        {
           return consultationRepository.findConsultation(date,user);
        }

        public List<ConsultationDto> listerConsultationParDate(string date)
        {
            return consultationRepository.findByConsultationParDate(date);
        }

        public List<Consultation> listerConsultationParPatient(Patient patient)
        {
            return consultationRepository.findConsultationsUnPatient(patient);
        }

        public Consultation rechercherConsultation(int id)
        {
            return consultationRepository.findById(id);
        }
    }
}
