﻿using Gestion_Rv.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public class FabriqueService
    {
        //Design pattern Fabrique:Centraliser la création des dépendances

        private static ISecurityService SecurityService;
        private static IRendezVousService rendezVousService;
        private static IConsultationService consultationService;
        private static IPrestationService prestationService;
        private static IPatientService patientService;
        private static IMedecinService medecinService;
        private static INotificationService notificationService;
        private static IOrdonnanceAndMedicamentService service;
        private static IPlanningService planningService;
        private static IUserService userService;
        private static string connectionString = "Data Source=DESKTOP-EU7HI99;Initial Catalog=GestionRv;Integrated Security=True";
        private static IUserRepository userRepository = new UserRepository(connectionString);
        private static IPatientRepository patientRepository = new PatientRepository(connectionString);
        private static IMedecinRepository medecinRepository = new MedecinRepository(connectionString);
        private static IOrdonnanceRepository  ordonnanceRepository= new OrdonnanceRepository(connectionString,patientRepository);
        private static IMedicamentRepository medicamentRepository = new MedicamentRepository(connectionString,ordonnanceRepository);
        private static IConsultationRepository consultationRepository = new ConsultationRepository(connectionString,patientRepository,medecinRepository);
        private static IRendezVousRepository rendezVousRepository =new RendezVousRepository(connectionString,patientRepository,userRepository);
        private static IPrestationRepository prestationRepository = new PrestationRepository(connectionString,patientRepository,userRepository);
        private static IPlanningRepository planningRepository = new PlanningRepository(connectionString,userRepository);

        public static ISecurityService GetSecurityService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return SecurityService == null ? new SecurityService(userRepository) : SecurityService;

        }

        public static IRendezVousService GetRendezVousService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return rendezVousService == null ? new RendezVousService(rendezVousRepository) : rendezVousService;

        }

        public static IConsultationService GetConsultationService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return consultationService == null ? new ConsultationService(consultationRepository) : consultationService;

        }

        public static IPrestationService GetPrestationService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return prestationService == null ? new PrestationService(prestationRepository) : prestationService;

        }

        public static IPatientService GetPatientService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return patientService == null ? new PatientService(patientRepository) : patientService;

        }

        public static IMedecinService GetMedecinService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return medecinService == null ? new MedecinService(medecinRepository) : medecinService;

        }

        public static IOrdonnanceAndMedicamentService GetOrdonnanceAndMedicamentService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return service == null ? new OrdonnanceAndMedicamentService(ordonnanceRepository,medicamentRepository) : service;

        }

        public static IPlanningService GetPlanningService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return planningService == null ? new PlanningService(planningRepository) : planningService;

        }

        public static IUserService GetUserService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return userService == null ? new UserService(userRepository) : userService;

        }

        public static INotificationService GetNotificationService()
        {
            //Design Pattern Singleton:Garantir l'unicité d'une instance

            return notificationService == null ? new NotificationService():notificationService;

        }

    }
}
