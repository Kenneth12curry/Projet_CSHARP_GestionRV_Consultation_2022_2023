﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public interface IConsultationService
    {
       
        List<ConsultationDto> findConsultationsPatients(Patient patient);
        List<Consultation> listerConsultationParPatient(Patient patient);
        List<ConsultationDto> listerConsultationParDate(string date);
        void enregistrerConsultation(Consultation consultation);
        List<ConsultationDto> listerConsultationMedecin(string date,User user);

        Consultation rechercherConsultation(int id);
    }
}
