﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public interface IMedecinService
    {
       
        List<Medecin> listeMedecin();
        Medecin rechercherMedecin(int id);
    }
}
