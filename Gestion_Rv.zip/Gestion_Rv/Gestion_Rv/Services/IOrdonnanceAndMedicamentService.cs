﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public interface IOrdonnanceAndMedicamentService
    {
        Ordonnance creerOrdonnance(Ordonnance ordonnance);
        void creerMedicament(Medicament medicament);
        Ordonnance rechercherOrdonnance(string numero);
        List<Ordonnance> listerOrdonnannceUnPatient(Patient patient);
        List<Ordonnance> listerOrdonnance();
        List<Medicament> listerMedicament();
        Medicament searchCode(string Code);
        List<Medicament> listerMedicamentUneOrdonnance(Ordonnance ordonnance);


    }
}
