﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public interface IPlanningService
    {
        void creerPlanning(Planning planning);
        List<Planning> listerPlanningByUser(User user);
        Planning rechercherPlanning(User user,string jour,string horaireDebut,string horaireFin);

    }
}
