﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public interface IRendezVousService
    {
        List<RendezVous> listerRv(string date);
        //List<RendezVous> listerRvConsultationJournée();
        void creerRendezVous(RendezVous rv);
        List<RendezVous> listerRdvUnUser(string date,User user);
        void annulerRdv(RendezVous rv);
        RendezVous searchRdv(string heure,string date,User user);
        void modifierRdv(RendezVous rv);
        List<RendezVous> listerRendezVous();


    }
}
