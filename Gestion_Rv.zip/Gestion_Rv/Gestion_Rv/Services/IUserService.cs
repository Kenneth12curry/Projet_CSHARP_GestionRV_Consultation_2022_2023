﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public interface IUserService
    {
        List<UserDto> listeUser(string role,string type);
        List<UserDto> listeUserByRole(string role);
        List<UserDto> listerUserParJour(string jour);
        RP rechercherRp(int id);
        User rechercherUser(int id);

    }
}
