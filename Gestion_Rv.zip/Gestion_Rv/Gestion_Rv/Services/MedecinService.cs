﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public class MedecinService : IMedecinService
    {
        private IMedecinRepository medecinRepository;
        public MedecinService(IMedecinRepository medecinRepository)
        {
            this.medecinRepository= medecinRepository;
        }

        public List<Medecin> listeMedecin()
        {
            return medecinRepository.findAll();
        }

        public Medecin rechercherMedecin(int id)
        {
           return medecinRepository.findById(id);
        }
    }
}
