﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public class NotificationService : INotificationService
    {

        public void sendmail(string email, string obj, string message)
        {
            // You should use a using statement
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
            {
                // Configure the client
                client.EnableSsl = true;
                client.Credentials = new NetworkCredential("adjeteken@gmail.com", "hbksspqsuyfddgqd");
                // client.UseDefaultCredentials = true;

                // A client has been created, now you need to create a MailMessage object
                MailMessage mail = new MailMessage(
                                         "adjeteken@gmail.com", // From field
                                         email, // Recipient field
                                         obj, // Subject of the email message
                                         message // Email message body
                                      );

                // Send the message
                client.Send(mail);

                /* 
                * Since I was using Console app, that is why I am able to use the Console
                * object, your framework would have different ones. 
                * There is actually no need for these following lines, you can ignore them
                * if you want to. SMTP protocol would still send the email of yours. */

                // Print a notification message
                //Console.WriteLine("Email has been sent.");
                // Just for the sake of pausing the application
                //Console.Read();

            }
        }
    }
}
