﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Repository
{
    public class OrdonnanceAndMedicamentService:IOrdonnanceAndMedicamentService
    {
        private IOrdonnanceRepository ordonnanceRepository;
        private IMedicamentRepository medicamentRepository;

        public OrdonnanceAndMedicamentService(IOrdonnanceRepository ordonnanceRepository, IMedicamentRepository medicamentRepository)
        {
            this.ordonnanceRepository = ordonnanceRepository;
            this.medicamentRepository = medicamentRepository;
        }

        public void creerMedicament(Medicament medicament)
        {
            medicamentRepository.insert(medicament);
        }

        public Ordonnance creerOrdonnance(Ordonnance ordonnance)
        {
            return ordonnanceRepository.insert_ordonnance(ordonnance);
        }

        public List<Medicament> listerMedicament()
        {
           return medicamentRepository.findAll();
        }

        public List<Medicament> listerMedicamentUneOrdonnance(Ordonnance ordonnance)
        {
            return medicamentRepository.findAll(ordonnance);
        }

        public List<Ordonnance> listerOrdonnance()
        {
           return ordonnanceRepository.findAll();
        }

        public List<Ordonnance> listerOrdonnannceUnPatient(Patient patient)
        {
           return ordonnanceRepository.findAll(patient);
        }

        public Ordonnance rechercherOrdonnance(string numero)
        {
            return ordonnanceRepository.findByNumero(numero);
        }

        public Medicament searchCode(string Code)
        {
            return medicamentRepository.findByCode(Code);
        }
    }
}
