﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public class PatientService:IPatientService
    {
        private IPatientRepository patientRepository;

        public PatientService(IPatientRepository patientRepository)
        {
            this.patientRepository = patientRepository;
        }

        public Patient creerPatient(Patient patient)
        {
            return patientRepository.persist(patient);
        }

        public List<PatientDto> listerPatient()
        {
            return patientRepository.findAll();
        }

        public PatientDto rechercherPatient(string nom)
        {
           return patientRepository.findByTel(nom);
        }
    }
}
