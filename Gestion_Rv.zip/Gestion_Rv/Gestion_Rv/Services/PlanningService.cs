﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public class PlanningService:IPlanningService
    {
        private IPlanningRepository planningRepository;

        public PlanningService(IPlanningRepository planningRepository)
        {
            this.planningRepository = planningRepository;
        }

        public void creerPlanning(Planning planning)
        {
            planningRepository.insert(planning);
        }

        public List<Planning> listerPlanningByUser(User user)
        {
            return planningRepository.findAll(user);
        }

        public Planning rechercherPlanning(User user, string jour, string horaireDebut, string horaireFin)
        {
           return planningRepository.findByPlanning(user,jour,horaireDebut,horaireFin);
        }
    }
}
