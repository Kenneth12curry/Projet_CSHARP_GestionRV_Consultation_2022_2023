﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public class PrestationService:IPrestationService
    {
        private IPrestationRepository prestationRepository;

        public PrestationService(IPrestationRepository prestationRepository)
        {
            this.prestationRepository = prestationRepository;
        }

        public void EnregisterPrestation(Prestation prestation)
        {
            prestationRepository.insert(prestation);
        }

        public List<PrestationDto> listerPrestationsUNRp(string date, User user)
        {
            return prestationRepository.findPrestations(date,user);
        }

        public List<PrestationDto> listerPrestationParDate(string date)
        {
            return prestationRepository.findPrestationsParDate(date);
        }

        public List<PrestationDto> listerPrestationParPatient(Patient patient)
        {
            return prestationRepository.findPrestationsUnPatient(patient);
        }
    }
}
