﻿using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public class RendezVousService :IRendezVousService
    {
        private IRendezVousRepository rendezVousRepository;
        

        public RendezVousService(IRendezVousRepository rendezVousRepository)
        {
            this.rendezVousRepository = rendezVousRepository;
            
        }


        public List<RendezVous> listerRv(string date)
        {
            return rendezVousRepository.findAll(date);
        }

        public void creerRendezVous(RendezVous rv)
        {
            rendezVousRepository.insert(rv);
        }

        public void annulerRdv(RendezVous rv)
        {
            rendezVousRepository.insert(rv);
        }

        public List<RendezVous> listerRdvUnUser(string date, User user)
        {
            return rendezVousRepository.findRdvByUser(date, user);
        }

        public RendezVous searchRdv(string heure, string date, User user)
        {
            return rendezVousRepository.findrdv(heure,date,user);
        }

        public List<RendezVous> listerRendezVous()
        {
            return rendezVousRepository.findAll();
        }

        public void modifierRdv(RendezVous rv)
        {
             rendezVousRepository.insert(rv);
        }
    }
}
