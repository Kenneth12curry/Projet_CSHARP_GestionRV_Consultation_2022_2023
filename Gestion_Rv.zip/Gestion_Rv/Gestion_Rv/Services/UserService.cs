﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using Gestion_Rv.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Services
{
    public  class UserService:IUserService
    {
        private IUserRepository userRepository;

        public UserService(IUserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        public List<UserDto> listerUserParJour(string jour)
        {
            return userRepository.findAll(jour);
        }

        public List<UserDto> listeUser(string role,string type)
        {
            return userRepository.finduser(role,type);
        }

        public List<UserDto> listeUserByRole(string role)
        {
            return userRepository.findUserByRole(role);
        }

        public RP rechercherRp(int id)
        {
            return userRepository.findByIdRP(id);
        }

        public User rechercherUser(int id)
        {
            return userRepository.findById(id);
        }
    }
}
