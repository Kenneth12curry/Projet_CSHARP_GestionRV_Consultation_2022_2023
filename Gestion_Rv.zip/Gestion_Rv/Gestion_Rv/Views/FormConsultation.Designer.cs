﻿namespace Gestion_Rv.Views
{
    partial class FormConsultation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDate = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cboPatient = new System.Windows.Forms.ComboBox();
            this.dtgvConsultation = new System.Windows.Forms.DataGridView();
            this.cboDate = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelPatient = new System.Windows.Forms.Panel();
            this.btnPatient = new System.Windows.Forms.Button();
            this.btnDetails = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvConsultation)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelPatient.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDate
            // 
            this.btnDate.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDate.Location = new System.Drawing.Point(301, 56);
            this.btnDate.Name = "btnDate";
            this.btnDate.Size = new System.Drawing.Size(44, 21);
            this.btnDate.TabIndex = 5;
            this.btnDate.Text = "Ok";
            this.btnDate.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(20, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(23, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 3;
            this.label1.Text = "Patient";
            // 
            // cboPatient
            // 
            this.cboPatient.FormattingEnabled = true;
            this.cboPatient.Location = new System.Drawing.Point(90, 16);
            this.cboPatient.Name = "cboPatient";
            this.cboPatient.Size = new System.Drawing.Size(241, 25);
            this.cboPatient.TabIndex = 1;
            // 
            // dtgvConsultation
            // 
            this.dtgvConsultation.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.dtgvConsultation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvConsultation.Location = new System.Drawing.Point(16, 109);
            this.dtgvConsultation.Name = "dtgvConsultation";
            this.dtgvConsultation.Size = new System.Drawing.Size(757, 368);
            this.dtgvConsultation.TabIndex = 0;
            this.dtgvConsultation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvConsultation_CellContentClick);
            // 
            // cboDate
            // 
            this.cboDate.Location = new System.Drawing.Point(66, 56);
            this.cboDate.Name = "cboDate";
            this.cboDate.Size = new System.Drawing.Size(215, 25);
            this.cboDate.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(60)))));
            this.panel1.Controls.Add(this.panelPatient);
            this.panel1.Controls.Add(this.btnDetails);
            this.panel1.Controls.Add(this.dtgvConsultation);
            this.panel1.Controls.Add(this.btnDate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cboDate);
            this.panel1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(23, 132);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(894, 499);
            this.panel1.TabIndex = 6;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panelPatient
            // 
            this.panelPatient.Controls.Add(this.cboPatient);
            this.panelPatient.Controls.Add(this.label1);
            this.panelPatient.Controls.Add(this.btnPatient);
            this.panelPatient.Location = new System.Drawing.Point(365, 43);
            this.panelPatient.Name = "panelPatient";
            this.panelPatient.Size = new System.Drawing.Size(413, 48);
            this.panelPatient.TabIndex = 8;
            // 
            // btnPatient
            // 
            this.btnPatient.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnPatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPatient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatient.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPatient.Location = new System.Drawing.Point(353, 16);
            this.btnPatient.Name = "btnPatient";
            this.btnPatient.Size = new System.Drawing.Size(45, 21);
            this.btnPatient.TabIndex = 7;
            this.btnPatient.Text = "Ok";
            this.btnPatient.UseVisualStyleBackColor = false;
            // 
            // btnDetails
            // 
            this.btnDetails.BackColor = System.Drawing.Color.Green;
            this.btnDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDetails.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDetails.Location = new System.Drawing.Point(779, 109);
            this.btnDetails.Name = "btnDetails";
            this.btnDetails.Size = new System.Drawing.Size(100, 37);
            this.btnDetails.TabIndex = 8;
            this.btnDetails.Text = "Détails Consultation";
            this.btnDetails.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(359, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(207, 22);
            this.label3.TabIndex = 7;
            this.label3.Text = "Listes des Consultations";
            // 
            // FormConsultation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1014, 663);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormConsultation";
            this.Text = "FormConsultation";
            this.Load += new System.EventHandler(this.FormConsultation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvConsultation)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelPatient.ResumeLayout(false);
            this.panelPatient.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dtgvConsultation;
        private System.Windows.Forms.DateTimePicker cboDate;
        private System.Windows.Forms.ComboBox cboPatient;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPatient;
        private System.Windows.Forms.Button btnDetails;
        private System.Windows.Forms.Panel panelPatient;
    }
}