﻿using Gestion_Rv.Dto;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormConsultation : Form,IConsultationView
    {
        public FormConsultation()
        {
            InitializeComponent();
            //Mapping => delegate
            btnDate.Click += delegate { showFiltreConsultationEvent.Invoke(btnDate, EventArgs.Empty); };
            btnPatient.Click += delegate { showFiltreConsultationEvent.Invoke(btnPatient, EventArgs.Empty); };
            btnDetails.Click += delegate { showFormDetailsConsultationsEvent.Invoke(this, EventArgs.Empty); };

        }

        //events
        public event EventHandler showFiltreConsultationEvent;
        public event EventHandler showFormDetailsConsultationsEvent;

        public PatientDto listPatient { get => cboPatient.SelectedItem as PatientDto ; set => throw new NotImplementedException(); }
        public DateTime Date { get => cboDate.Value; set => throw new NotImplementedException(); }
        public bool PanelPatient { get => panelPatient.Visible; set => panelPatient.Visible=value; }

        //Design Pattern => Singleton

        private static FormConsultation instance = null;
        public static FormConsultation showForm(Form parent)
        {
            if (parent.ActiveMdiChild != null)
            {
                parent.ActiveMdiChild.Hide();
                instance = null;
               

            }
            if (instance == null || instance.IsDisposed)
            {
                instance = new FormConsultation();
                instance.MdiParent = parent;
            }
            return instance;
        }

        public void setConsultationBidingSource(BindingSource consultationList, BindingSource patientList)
        {
            dtgvConsultation.DataSource = consultationList;
            cboPatient.DataSource = patientList;
            dtgvConsultation.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dtgvConsultation_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormConsultation_Load(object sender, EventArgs e)
        {

        }
    }
}
