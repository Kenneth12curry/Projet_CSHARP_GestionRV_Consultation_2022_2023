﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormConsultationsAndPrestationsPatient : Form,IConsultationsAndPrestationsPatientView
    {
       
        public FormConsultationsAndPrestationsPatient()
        {
            InitializeComponent();
            //Mapping => delegate
            btnPrestation.Click += delegate { showFormEvent.Invoke(btnPrestation, EventArgs.Empty); };
            btnConsultation.Click += delegate { showFormEvent.Invoke(btnConsultation, EventArgs.Empty); };
            FormClosed += delegate { closeFenenetreEvent.Invoke(this, EventArgs.Empty); };

        }

        public string nomPatient { get => throw new NotImplementedException(); set => lblNom.Text=value; }
        public string prenomPatient { get => throw new NotImplementedException(); set => lblPrenom.Text=value; }
        public string codePatient { get => throw new NotImplementedException(); set => lblCode.Text=value; }

        //events=> évènements

        public event EventHandler showFormEvent;
        public event EventHandler closeFenenetreEvent;

        public void setConsultationsAndPrestationBidingSource(BindingSource consultationsPrestationsList)
        {
            dtgvConsultation.DataSource=consultationsPrestationsList;
            dtgvConsultation.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void FormConsultationsAndPrestationsPatient_Load(object sender, EventArgs e)
        {

        }

        private void dtgvConsultation_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
