﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormCreationPatient : Form,ICreationPatientView
    {
        public FormCreationPatient()
        {
            InitializeComponent();
            btnEnregistrer.Click += delegate { ajouterPatientEvent.Invoke(this, EventArgs.Empty); };

        }

        public string nomPatient { get => txtNom.Text.Trim(); set => txtNom.Text=value; }
        public string prenomPatient { get => txtPrenom.Text.Trim(); set => txtPrenom.Text=value; }
        public string emailPatient { get => txtEmail.Text.Trim(); set => txtEmail.Text=value; }
        public string telPatient { get => txtTel.Text.Trim(); set => txtTel.Text=value; }

        public event EventHandler ajouterPatientEvent;

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void FormCreationPatient_Load(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
