﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormDetailsConsultation : Form,IDetailsConsultationView
    {

        public FormDetailsConsultation()
        {
            InitializeComponent();
            dtgvMedicament.Click += delegate { showMedicament.Invoke(this, EventArgs.Empty); };
            dtgvOrdonnance.SelectionChanged += delegate { SelectionLigneDtgvEvent.Invoke(this, EventArgs.Empty); };
        }



        public string nomPatient { get => throw new NotImplementedException(); set => lblNom.Text=value; }
        public string prenomPatient { get => throw new NotImplementedException(); set => lblPrenom.Text=value; }
        public string codePatient { get => throw new NotImplementedException(); set => lblCode.Text=value; }
        public string date { get => throw new NotImplementedException(); set => lblDate.Text=value; }
        public string temperature { get => throw new NotImplementedException(); set => lblTemperature.Text=value; }
        public string tension { get => throw new NotImplementedException(); set => lblTension.Text=value; }
        public string poids { get => throw new NotImplementedException(); set => lblPoids.Text=value; }
        public string motif { get => throw new NotImplementedException(); set => lblMotif.Text=value; }
        public string nomMedecin { get => throw new NotImplementedException(); set => lblNomMedecin.Text=value; }
        public string prenomMedecin { get => throw new NotImplementedException(); set => lblPrenomMedecin.Text=value; }
        public string typeMedecin { get => throw new NotImplementedException(); set => lblTypeMedecin.Text=value; }
       

        //events=>évènements
        public event EventHandler showMedicament;
        public event EventHandler SelectionLigneDtgvEvent;

        public void setBidingSource(BindingSource ordonnanceList)
        {
            dtgvOrdonnance.DataSource=ordonnanceList;
        }

        public void setMedicamentBidingSource(BindingSource medicamentList)
        {
            dtgvMedicament.DataSource=medicamentList;
        }

        private void FormDetailsConsultation_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
