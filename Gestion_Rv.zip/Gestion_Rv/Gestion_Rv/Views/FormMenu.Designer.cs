﻿namespace Gestion_Rv.Views
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenu));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnPlanning = new System.Windows.Forms.Button();
            this.btnConsultation = new System.Windows.Forms.Button();
            this.btnPrestation = new System.Windows.Forms.Button();
            this.btnPatient = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnDeconnexion = new System.Windows.Forms.Button();
            this.btnRv = new System.Windows.Forms.Button();
            this.lblUserConnect = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(this.btnPlanning);
            this.panel1.Controls.Add(this.btnConsultation);
            this.panel1.Controls.Add(this.btnPrestation);
            this.panel1.Controls.Add(this.btnPatient);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btnDeconnexion);
            this.panel1.Controls.Add(this.btnRv);
            this.panel1.Controls.Add(this.lblUserConnect);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(197, 695);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnPlanning
            // 
            this.btnPlanning.BackColor = System.Drawing.Color.Green;
            this.btnPlanning.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlanning.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlanning.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPlanning.Location = new System.Drawing.Point(12, 324);
            this.btnPlanning.Name = "btnPlanning";
            this.btnPlanning.Size = new System.Drawing.Size(155, 26);
            this.btnPlanning.TabIndex = 7;
            this.btnPlanning.Text = "Planning";
            this.btnPlanning.UseVisualStyleBackColor = false;
            // 
            // btnConsultation
            // 
            this.btnConsultation.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnConsultation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConsultation.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConsultation.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnConsultation.Location = new System.Drawing.Point(12, 176);
            this.btnConsultation.Name = "btnConsultation";
            this.btnConsultation.Size = new System.Drawing.Size(155, 24);
            this.btnConsultation.TabIndex = 1;
            this.btnConsultation.Text = "Consultation";
            this.btnConsultation.UseVisualStyleBackColor = false;
            // 
            // btnPrestation
            // 
            this.btnPrestation.BackColor = System.Drawing.Color.Blue;
            this.btnPrestation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPrestation.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrestation.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPrestation.Location = new System.Drawing.Point(12, 226);
            this.btnPrestation.Name = "btnPrestation";
            this.btnPrestation.Size = new System.Drawing.Size(155, 24);
            this.btnPrestation.TabIndex = 2;
            this.btnPrestation.Text = "Prestation";
            this.btnPrestation.UseVisualStyleBackColor = false;
            // 
            // btnPatient
            // 
            this.btnPatient.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnPatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPatient.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatient.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPatient.Location = new System.Drawing.Point(12, 374);
            this.btnPatient.Name = "btnPatient";
            this.btnPatient.Size = new System.Drawing.Size(155, 24);
            this.btnPatient.TabIndex = 6;
            this.btnPatient.Text = "Patient";
            this.btnPatient.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(38, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btnDeconnexion
            // 
            this.btnDeconnexion.BackColor = System.Drawing.Color.Red;
            this.btnDeconnexion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeconnexion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeconnexion.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDeconnexion.Location = new System.Drawing.Point(12, 574);
            this.btnDeconnexion.Name = "btnDeconnexion";
            this.btnDeconnexion.Size = new System.Drawing.Size(155, 24);
            this.btnDeconnexion.TabIndex = 5;
            this.btnDeconnexion.Text = "Deconnexion";
            this.btnDeconnexion.UseVisualStyleBackColor = false;
            // 
            // btnRv
            // 
            this.btnRv.BackColor = System.Drawing.Color.Navy;
            this.btnRv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRv.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRv.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRv.Location = new System.Drawing.Point(12, 277);
            this.btnRv.Name = "btnRv";
            this.btnRv.Size = new System.Drawing.Size(155, 24);
            this.btnRv.TabIndex = 3;
            this.btnRv.Text = "Rendez-Vous";
            this.btnRv.UseVisualStyleBackColor = false;
            // 
            // lblUserConnect
            // 
            this.lblUserConnect.AutoSize = true;
            this.lblUserConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserConnect.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblUserConnect.Location = new System.Drawing.Point(35, 97);
            this.lblUserConnect.Name = "lblUserConnect";
            this.lblUserConnect.Size = new System.Drawing.Size(96, 16);
            this.lblUserConnect.TabIndex = 0;
            this.lblUserConnect.Text = "UserConnect";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(80)))));
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(197, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1031, 35);
            this.panel2.TabIndex = 2;
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1228, 695);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.IsMdiContainer = true;
            this.Name = "FormMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormMenu";
            this.Load += new System.EventHandler(this.FormMenu_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnConsultation;
        private System.Windows.Forms.Label lblUserConnect;
        private System.Windows.Forms.Button btnDeconnexion;
        private System.Windows.Forms.Button btnRv;
        private System.Windows.Forms.Button btnPrestation;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnPatient;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnPlanning;
    }
}