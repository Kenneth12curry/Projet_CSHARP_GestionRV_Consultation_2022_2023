﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormMenu : Form,IMenuView
    {
        public FormMenu()
        {
            InitializeComponent();
            this.activeEvent();
            
        }


        public void activeEvent()
        {
            //Mapping => delegate
            btnConsultation.Click += delegate { showFormEvent.Invoke(btnConsultation, EventArgs.Empty); };
            btnPrestation.Click += delegate { showFormEvent.Invoke(btnPrestation, EventArgs.Empty); };
            btnRv.Click += delegate { showFormEvent.Invoke(btnRv, EventArgs.Empty); };
            btnPatient.Click += delegate { showFormEvent.Invoke(btnPatient, EventArgs.Empty); };
            btnPlanning.Click += delegate { showFormEvent.Invoke(btnPlanning, EventArgs.Empty); };
            btnDeconnexion.Click += delegate { showFormEvent.Invoke(btnDeconnexion, EventArgs.Empty); };
            //Chargement de la vue rendez-vous au lançement de la page de menu
            Load += delegate { showFormEvent.Invoke(btnRv, EventArgs.Empty); };
            //FormClosed += delegate { closeFenetreEvent.Invoke(this, EventArgs.Empty); };

        }

        public string userLabel { get => lblUserConnect.Text; set => lblUserConnect.Text=value; }
        public User userConnect { get; set; }
        public bool consultation { get => btnConsultation.Visible; set => btnConsultation.Visible=value; }
        public bool prestation { get => btnPrestation.Visible; set => btnPrestation.Visible = value; }
        public bool rendezVous { get => btnRv.Visible; set => btnRv.Visible = value; }
        public bool patient { get => btnPatient.Visible; set => btnPatient.Visible = value; }
        public bool planning { get => btnPlanning.Visible; set => btnPlanning.Visible=value; }

        //events => évènements
        public event EventHandler showFormEvent;
        public event EventHandler closeFenetreEvent;

        private void FormMenu_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
