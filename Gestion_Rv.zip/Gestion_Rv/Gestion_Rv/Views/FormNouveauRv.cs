﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormNouveauRv : Form,INouveauRvView
    {
       

        public FormNouveauRv()
        {
            InitializeComponent();
            //Mapping => delegate
            btnAdd.Click += delegate { creerRdvEvent.Invoke(this, EventArgs.Empty); };
            btnSearch.Click += delegate { searchEvent.Invoke(this, EventArgs.Empty); };
            btnSend.Click += delegate { sendMailEvent.Invoke(this, EventArgs.Empty); };
            dtgvUser.SelectionChanged += delegate { SelectionLigneDtgvEvent.Invoke(this, EventArgs.Empty); };

        }

        public string heure { get => comboHeure.SelectedItem as string; set => throw new NotImplementedException(); }
        public string typeRdv { get => comboRdv.SelectedItem as string; set => throw new NotImplementedException(); }
        public string emailPatient { get => txtemail.Text.Trim(); set => txtemail.Text=value; }
        public string objectMessage { get => txtObject.Text.Trim(); set => txtObject.Text=value; }
        public string Message { get => txtMessage.Text.Trim(); set => txtMessage.Text=value; }
        public DateTime date { get => comboDate.Value; set => throw new NotImplementedException(); }
        public string jour { get => comboJour.SelectedItem as string ; set => throw new NotImplementedException(); }
        public string nomPatient { get => throw new NotImplementedException(); set => lblNom.Text=value; }
        public string prenomPatient { get => throw new NotImplementedException(); set => lblPrenom.Text=value; }
        public string codePatient { get => throw new NotImplementedException(); set =>lblCode.Text=value; }
        public bool mail { get => panelMail.Enabled; set => panelMail.Enabled=value; }
        public string emailPatient1 { get => throw new NotImplementedException(); set => txtemail.Text=value; }

        //events

        public event EventHandler creerRdvEvent;
        public event EventHandler searchEvent;
        public event EventHandler sendMailEvent;
        public event EventHandler SelectionLigneDtgvEvent;

        public void setBindingSource(BindingSource userList)
        {
           dtgvUser.DataSource = userList;
           dtgvUser.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public void setList(BindingSource heureList, BindingSource jourList, BindingSource rdvList)
        {
            comboHeure.DataSource = heureList;
            comboJour.DataSource = jourList;
            comboRdv.DataSource = rdvList;

        }

        public void setBidingSource(BindingSource planningListUser)
        {
            dtgvPlanning.DataSource = planningListUser;
        }

       
    }
}
