﻿namespace Gestion_Rv.Views
{
    partial class FormNouvelleConsultation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTemperature = new System.Windows.Forms.TextBox();
            this.txtTension = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnEnregistrer = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.OrdonnanceBox = new System.Windows.Forms.GroupBox();
            this.btnCreer = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtOrdonnance = new System.Windows.Forms.TextBox();
            this.panelMed = new System.Windows.Forms.Panel();
            this.btnAjout = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPosologie = new System.Windows.Forms.RichTextBox();
            this.txtCode = new System.Windows.Forms.TextBox();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.choixOui = new System.Windows.Forms.RadioButton();
            this.txtMotif = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPoids = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.choixNon = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.txtMedecin = new System.Windows.Forms.TextBox();
            this.txtPatient = new System.Windows.Forms.TextBox();
            this.consultation = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.Ordonnance = new System.Windows.Forms.GroupBox();
            this.OrdonnanceBox.SuspendLayout();
            this.panelMed.SuspendLayout();
            this.consultation.SuspendLayout();
            this.Ordonnance.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(36, 90);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(27, 145);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Medecin";
            // 
            // txtTemperature
            // 
            this.txtTemperature.Location = new System.Drawing.Point(115, 255);
            this.txtTemperature.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTemperature.Name = "txtTemperature";
            this.txtTemperature.Size = new System.Drawing.Size(271, 22);
            this.txtTemperature.TabIndex = 4;
            // 
            // txtTension
            // 
            this.txtTension.Location = new System.Drawing.Point(115, 359);
            this.txtTension.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtTension.Name = "txtTension";
            this.txtTension.Size = new System.Drawing.Size(271, 22);
            this.txtTension.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(14, 261);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Température";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(35, 365);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Tension";
            // 
            // btnEnregistrer
            // 
            this.btnEnregistrer.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnEnregistrer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnregistrer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnEnregistrer.Location = new System.Drawing.Point(115, 557);
            this.btnEnregistrer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnEnregistrer.Name = "btnEnregistrer";
            this.btnEnregistrer.Size = new System.Drawing.Size(272, 31);
            this.btnEnregistrer.TabIndex = 8;
            this.btnEnregistrer.Text = "Enregistrer";
            this.btnEnregistrer.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(35, 195);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 15);
            this.label5.TabIndex = 10;
            this.label5.Text = "Patient";
            // 
            // OrdonnanceBox
            // 
            this.OrdonnanceBox.Controls.Add(this.btnCreer);
            this.OrdonnanceBox.Controls.Add(this.label9);
            this.OrdonnanceBox.Controls.Add(this.txtOrdonnance);
            this.OrdonnanceBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrdonnanceBox.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.OrdonnanceBox.Location = new System.Drawing.Point(36, 81);
            this.OrdonnanceBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.OrdonnanceBox.Name = "OrdonnanceBox";
            this.OrdonnanceBox.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.OrdonnanceBox.Size = new System.Drawing.Size(454, 76);
            this.OrdonnanceBox.TabIndex = 11;
            this.OrdonnanceBox.TabStop = false;
            this.OrdonnanceBox.Text = "Ordonnance";
            // 
            // btnCreer
            // 
            this.btnCreer.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnCreer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCreer.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnCreer.Location = new System.Drawing.Point(362, 24);
            this.btnCreer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCreer.Name = "btnCreer";
            this.btnCreer.Size = new System.Drawing.Size(65, 27);
            this.btnCreer.TabIndex = 18;
            this.btnCreer.Text = "Creer";
            this.btnCreer.UseVisualStyleBackColor = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label9.Location = new System.Drawing.Point(41, 33);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 15);
            this.label9.TabIndex = 18;
            this.label9.Text = "Libelle";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // txtOrdonnance
            // 
            this.txtOrdonnance.Location = new System.Drawing.Point(134, 28);
            this.txtOrdonnance.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtOrdonnance.Name = "txtOrdonnance";
            this.txtOrdonnance.Size = new System.Drawing.Size(207, 20);
            this.txtOrdonnance.TabIndex = 17;
            // 
            // panelMed
            // 
            this.panelMed.Controls.Add(this.btnAjout);
            this.panelMed.Controls.Add(this.label10);
            this.panelMed.Controls.Add(this.txtPosologie);
            this.panelMed.Controls.Add(this.txtCode);
            this.panelMed.Controls.Add(this.txtNom);
            this.panelMed.Controls.Add(this.label6);
            this.panelMed.Controls.Add(this.label7);
            this.panelMed.Controls.Add(this.label8);
            this.panelMed.Location = new System.Drawing.Point(36, 185);
            this.panelMed.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.panelMed.Name = "panelMed";
            this.panelMed.Size = new System.Drawing.Size(454, 355);
            this.panelMed.TabIndex = 19;
            this.panelMed.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnAjout
            // 
            this.btnAjout.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAjout.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAjout.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAjout.Location = new System.Drawing.Point(270, 317);
            this.btnAjout.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnAjout.Name = "btnAjout";
            this.btnAjout.Size = new System.Drawing.Size(99, 31);
            this.btnAjout.TabIndex = 12;
            this.btnAjout.Text = "Ajouter";
            this.btnAjout.UseVisualStyleBackColor = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(156, 15);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 15);
            this.label10.TabIndex = 17;
            this.label10.Text = "Médicaments";
            // 
            // txtPosologie
            // 
            this.txtPosologie.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPosologie.Location = new System.Drawing.Point(97, 170);
            this.txtPosologie.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPosologie.Name = "txtPosologie";
            this.txtPosologie.Size = new System.Drawing.Size(271, 125);
            this.txtPosologie.TabIndex = 14;
            this.txtPosologie.Text = "";
            // 
            // txtCode
            // 
            this.txtCode.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCode.Location = new System.Drawing.Point(97, 50);
            this.txtCode.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtCode.Name = "txtCode";
            this.txtCode.Size = new System.Drawing.Size(271, 22);
            this.txtCode.TabIndex = 12;
            // 
            // txtNom
            // 
            this.txtNom.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNom.Location = new System.Drawing.Point(97, 105);
            this.txtNom.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(271, 22);
            this.txtNom.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(35, 51);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(34, 15);
            this.label6.TabIndex = 12;
            this.label6.Text = "Code";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(35, 105);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 15);
            this.label7.TabIndex = 15;
            this.label7.Text = "Nom";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 173);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 15);
            this.label8.TabIndex = 16;
            this.label8.Text = "Posologie";
            // 
            // choixOui
            // 
            this.choixOui.AutoSize = true;
            this.choixOui.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.choixOui.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.choixOui.Location = new System.Drawing.Point(24, 52);
            this.choixOui.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.choixOui.Name = "choixOui";
            this.choixOui.Size = new System.Drawing.Size(46, 19);
            this.choixOui.TabIndex = 12;
            this.choixOui.Text = "Oui";
            this.choixOui.UseVisualStyleBackColor = true;
            // 
            // txtMotif
            // 
            this.txtMotif.Location = new System.Drawing.Point(115, 404);
            this.txtMotif.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtMotif.Name = "txtMotif";
            this.txtMotif.Size = new System.Drawing.Size(271, 117);
            this.txtMotif.TabIndex = 13;
            this.txtMotif.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(31, 423);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 15);
            this.label11.TabIndex = 14;
            this.label11.Text = "Motif";
            // 
            // txtPoids
            // 
            this.txtPoids.Location = new System.Drawing.Point(115, 307);
            this.txtPoids.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPoids.Name = "txtPoids";
            this.txtPoids.Size = new System.Drawing.Size(271, 22);
            this.txtPoids.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label12.Location = new System.Drawing.Point(50, 313);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 15);
            this.label12.TabIndex = 16;
            this.label12.Text = "Poids";
            // 
            // choixNon
            // 
            this.choixNon.AutoSize = true;
            this.choixNon.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.choixNon.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.choixNon.Location = new System.Drawing.Point(119, 52);
            this.choixNon.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.choixNon.Name = "choixNon";
            this.choixNon.Size = new System.Drawing.Size(47, 19);
            this.choixNon.TabIndex = 17;
            this.choixNon.Text = "Non";
            this.choixNon.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label13.Location = new System.Drawing.Point(20, 18);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(248, 19);
            this.label13.TabIndex = 18;
            this.label13.Text = "Voulez vous creer une ordonnance ?";
            // 
            // txtDate
            // 
            this.txtDate.Location = new System.Drawing.Point(26, 15);
            this.txtDate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(247, 22);
            this.txtDate.TabIndex = 19;
            // 
            // txtMedecin
            // 
            this.txtMedecin.Location = new System.Drawing.Point(26, 68);
            this.txtMedecin.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtMedecin.Name = "txtMedecin";
            this.txtMedecin.Size = new System.Drawing.Size(247, 22);
            this.txtMedecin.TabIndex = 20;
            // 
            // txtPatient
            // 
            this.txtPatient.Location = new System.Drawing.Point(26, 114);
            this.txtPatient.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtPatient.Name = "txtPatient";
            this.txtPatient.Size = new System.Drawing.Size(247, 22);
            this.txtPatient.TabIndex = 21;
            // 
            // consultation
            // 
            this.consultation.Controls.Add(this.txtDate);
            this.consultation.Controls.Add(this.txtPatient);
            this.consultation.Controls.Add(this.txtMedecin);
            this.consultation.Location = new System.Drawing.Point(96, 75);
            this.consultation.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.consultation.Name = "consultation";
            this.consultation.Size = new System.Drawing.Size(313, 159);
            this.consultation.TabIndex = 22;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label14.Location = new System.Drawing.Point(91, 28);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(218, 19);
            this.label14.TabIndex = 23;
            this.label14.Text = "Informations de la Consultation";
            // 
            // Ordonnance
            // 
            this.Ordonnance.Controls.Add(this.label13);
            this.Ordonnance.Controls.Add(this.OrdonnanceBox);
            this.Ordonnance.Controls.Add(this.panelMed);
            this.Ordonnance.Controls.Add(this.choixOui);
            this.Ordonnance.Controls.Add(this.choixNon);
            this.Ordonnance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ordonnance.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Ordonnance.Location = new System.Drawing.Point(436, 28);
            this.Ordonnance.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Ordonnance.Name = "Ordonnance";
            this.Ordonnance.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Ordonnance.Size = new System.Drawing.Size(519, 569);
            this.Ordonnance.TabIndex = 24;
            this.Ordonnance.TabStop = false;
            this.Ordonnance.Text = "informations Ordonnance";
            this.Ordonnance.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // FormNouvelleConsultation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(988, 639);
            this.Controls.Add(this.Ordonnance);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.consultation);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtPoids);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtMotif);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnEnregistrer);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtTension);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTemperature);
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FormNouvelleConsultation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FormNouvelleConsultation";
            this.Load += new System.EventHandler(this.FormNouvelleConsultation_Load);
            this.OrdonnanceBox.ResumeLayout(false);
            this.OrdonnanceBox.PerformLayout();
            this.panelMed.ResumeLayout(false);
            this.panelMed.PerformLayout();
            this.consultation.ResumeLayout(false);
            this.consultation.PerformLayout();
            this.Ordonnance.ResumeLayout(false);
            this.Ordonnance.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtTemperature;
        private System.Windows.Forms.TextBox txtTension;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnEnregistrer;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox OrdonnanceBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox txtPosologie;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.Panel panelMed;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtOrdonnance;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnAjout;
        private System.Windows.Forms.RadioButton choixOui;
        private System.Windows.Forms.RichTextBox txtMotif;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPoids;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnCreer;
        private System.Windows.Forms.RadioButton choixNon;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.TextBox txtMedecin;
        private System.Windows.Forms.TextBox txtPatient;
        private System.Windows.Forms.Panel consultation;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox Ordonnance;
    }
}