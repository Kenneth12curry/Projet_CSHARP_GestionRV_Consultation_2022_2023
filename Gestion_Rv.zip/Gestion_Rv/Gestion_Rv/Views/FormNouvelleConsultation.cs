﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormNouvelleConsultation : Form,INouvelleConsultationView
    {
        public FormNouvelleConsultation()
        {
            InitializeComponent();
            //Mapping => delegate
            btnEnregistrer.Click += delegate { enregistrerEvent.Invoke(this, EventArgs.Empty); };
            btnAjout.Click += delegate { ajoutMedEvent.Invoke(this, EventArgs.Empty); };
            choixOui.Click += delegate { radioButtonEvent.Invoke(choixOui, EventArgs.Empty); };
            choixNon.Click += delegate { radioButtonEvent.Invoke(choixNon, EventArgs.Empty); };
            btnCreer.Click += delegate { creerOrdonnanceEvent.Invoke(choixNon, EventArgs.Empty); };
        }

       
      
        public string saisieNumeroOrdonnance { get => txtOrdonnance.Text.Trim(); set => txtOrdonnance.Text=value; }
        public string saisieCode { get => txtCode.Text.Trim(); set => txtCode.Text=value; }
        public string saisieNom { get => txtNom.Text.Trim(); set => txtNom.Text=value; }
        public string saisiePosologie { get => txtPosologie.Text.Trim(); set => txtPosologie.Text=value; }

        public bool groupBoxOrdonnance { get => OrdonnanceBox.Enabled; set => OrdonnanceBox.Enabled=value; }
        public string saisiePoids { get => txtPoids.Text.Trim(); set => txtPoids.Text=value; }
        public string saisieMotif { get => txtMotif.Text.Trim(); set => txtMotif.Text=value; }
        public string saisieTemperature { get => txtTemperature.Text.Trim(); set => txtTemperature.Text = value; }
        public string saisieTension { get => txtTension.Text.Trim(); set => txtTension.Text = value; }


        public bool checkedRadio { get => choixOui.Checked; set => choixOui.Checked = value; }
        public bool checkedRadio1 { get => choixNon.Checked; set => choixNon.Checked = value; }
        public string Date { get => throw new NotImplementedException(); set => txtDate.Text=value; }
        public string Medecin { get => throw new NotImplementedException(); set => txtMedecin.Text=value; }
        public string Patient { get => throw new NotImplementedException(); set => txtPatient.Text=value; }
        public bool panelConsultation { get =>consultation.Enabled; set => consultation.Enabled=value; }
        bool INouvelleConsultationView.panelMed { get => panelMed.Enabled; set => panelMed.Enabled=value; }
        public bool panelOrdonnance { get => Ordonnance.Enabled; set => Ordonnance.Enabled=value; }
        public bool libelleOrdonnance { get => txtOrdonnance.Enabled; set => txtOrdonnance.Enabled=value; }

        public event EventHandler enregistrerEvent;
        public event EventHandler ajoutMedEvent;
        public event EventHandler radioButtonEvent;
        public event EventHandler creerOrdonnanceEvent;

        private void FormNouvelleConsultation_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
