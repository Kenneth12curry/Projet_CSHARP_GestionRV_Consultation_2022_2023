﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormNouvellePrestation : Form,INouvellePrestationView
    {
       
        public FormNouvellePrestation()
        {
            InitializeComponent();
            btnEnregistrer.Click += delegate { enregistrerAndannulerPrestationEvent.Invoke(this, EventArgs.Empty); };
         
        }

        //events
        public event EventHandler enregistrerAndannulerPrestationEvent;
     
        public string Date { get => throw new NotImplementedException(); set => lblDate.Text=value; }
        public string Patient { get => throw new NotImplementedException(); set =>lblPatient.Text=value; }
        public string typePrestation { get => cboType.SelectedItem as string ; set => throw new NotImplementedException(); }
        public bool prestation { get => panelPrestation.Enabled; set => panelPrestation.Enabled=value; }

        public void setBidingSource(BindingSource typePlist)
        {
            cboType.DataSource=typePlist;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
