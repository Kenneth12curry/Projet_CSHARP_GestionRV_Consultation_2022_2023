﻿namespace Gestion_Rv.Views
{
    partial class FormPatient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnRecherche = new System.Windows.Forms.Button();
            this.txtRecherche = new System.Windows.Forms.TextBox();
            this.btnDossier = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dtgvPatient = new System.Windows.Forms.DataGridView();
            this.btnRdv = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPatient)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(26, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Tel du Patient";
            // 
            // btnRecherche
            // 
            this.btnRecherche.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnRecherche.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRecherche.Location = new System.Drawing.Point(484, 24);
            this.btnRecherche.Name = "btnRecherche";
            this.btnRecherche.Size = new System.Drawing.Size(54, 26);
            this.btnRecherche.TabIndex = 6;
            this.btnRecherche.Text = "Ok";
            this.btnRecherche.UseVisualStyleBackColor = false;
            // 
            // txtRecherche
            // 
            this.txtRecherche.Location = new System.Drawing.Point(143, 26);
            this.txtRecherche.Name = "txtRecherche";
            this.txtRecherche.Size = new System.Drawing.Size(307, 25);
            this.txtRecherche.TabIndex = 5;
            // 
            // btnDossier
            // 
            this.btnDossier.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnDossier.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDossier.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDossier.Location = new System.Drawing.Point(738, 69);
            this.btnDossier.Name = "btnDossier";
            this.btnDossier.Size = new System.Drawing.Size(104, 43);
            this.btnDossier.TabIndex = 4;
            this.btnDossier.Text = "Dossier Médical";
            this.btnDossier.UseVisualStyleBackColor = false;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAdd.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAdd.Location = new System.Drawing.Point(796, 89);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(104, 31);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "ADD";
            this.btnAdd.UseVisualStyleBackColor = false;
            // 
            // dtgvPatient
            // 
            this.dtgvPatient.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.dtgvPatient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvPatient.Location = new System.Drawing.Point(29, 69);
            this.dtgvPatient.Name = "dtgvPatient";
            this.dtgvPatient.Size = new System.Drawing.Size(682, 330);
            this.dtgvPatient.TabIndex = 0;
            this.dtgvPatient.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvPatient_CellContentClick);
            // 
            // btnRdv
            // 
            this.btnRdv.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnRdv.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRdv.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnRdv.Location = new System.Drawing.Point(738, 132);
            this.btnRdv.Name = "btnRdv";
            this.btnRdv.Size = new System.Drawing.Size(104, 31);
            this.btnRdv.TabIndex = 8;
            this.btnRdv.Text = "Planifier Rdv";
            this.btnRdv.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(60)))));
            this.panel2.Controls.Add(this.dtgvPatient);
            this.panel2.Controls.Add(this.btnRdv);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.txtRecherche);
            this.panel2.Controls.Add(this.btnDossier);
            this.panel2.Controls.Add(this.btnRecherche);
            this.panel2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(39, 126);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(871, 443);
            this.panel2.TabIndex = 9;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(378, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(153, 22);
            this.label2.TabIndex = 10;
            this.label2.Text = "Liste des Patients";
            // 
            // FormPatient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(983, 636);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnAdd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormPatient";
            this.Text = "FormPatient";
            this.Load += new System.EventHandler(this.FormPatient_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPatient)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dtgvPatient;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnDossier;
        private System.Windows.Forms.TextBox txtRecherche;
        private System.Windows.Forms.Button btnRecherche;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRdv;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
    }
}