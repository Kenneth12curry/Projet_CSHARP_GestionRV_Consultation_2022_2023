﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormPatient : Form,IPatientView
    {
        public FormPatient()
        {
            InitializeComponent();
            this.activeEventClasse();
        }



        private void activeEventClasse()
        {
            //Mapping => delegate
            btnDossier.Click += delegate { loadViewConsultationsAndPrestationsUnPatient.Invoke(this, EventArgs.Empty); };
            btnAdd.Click += delegate { showPatientEvent.Invoke(this, EventArgs.Empty); };
            btnRecherche.Click += delegate { rechercherPatientEvent.Invoke(this, EventArgs.Empty); };
            btnRdv.Click += delegate { nouveauRvEvent.Invoke(this, EventArgs.Empty); };

        }


        //Propriétés
        public string nomRecherche { get => txtRecherche.Text.Trim(); set => txtRecherche.Text = value; }
        public bool patient { get => btnAdd.Visible; set => btnAdd.Visible=value; }
        public bool DossierMedical { get => btnDossier.Visible; set => btnDossier.Visible=value; }
        public bool planifierRdv { get => btnRdv.Visible; set => btnRdv.Visible=value; }


        //events

        public event EventHandler rechercherPatientEvent;
        public event EventHandler showPatientEvent;
        public event EventHandler loadViewConsultationsAndPrestationsUnPatient;
        public event EventHandler nouveauRvEvent;

       
        //Biding Source
        public void setPatientlist(BindingSource patientList)
        {
            dtgvPatient.DataSource=patientList;
        }


        //Design Pattern => Singleton

        private static FormPatient instance = null;

        public static FormPatient showForm(Form parent)
        {
            if (parent.ActiveMdiChild != null)
            {
                parent.ActiveMdiChild.Hide();
                instance = null;
            }
            if (instance == null || instance.IsDisposed)
            {
                instance = new FormPatient();
                instance.MdiParent = parent;
            }
            return instance;
        }

        private void dtgvPatient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormPatient_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
