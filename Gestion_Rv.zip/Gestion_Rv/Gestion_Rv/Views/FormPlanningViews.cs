﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormPlanningViews : Form,IPlanningViews
    {
        public FormPlanningViews()
        {
            InitializeComponent();
            btnAjouter.Click += delegate { AjouterPlanningMedecinEvent.Invoke(this, EventArgs.Empty); };
            btnFiltrer.Click += delegate { filtrerUserByRoleEvent.Invoke(this, EventArgs.Empty); };
            dtgvUser.SelectionChanged += delegate { SelectionLigneDtgvEvent.Invoke(this, EventArgs.Empty); };
        }

        //Propriétés
        public string jourSemaine { get => cboJour.SelectedItem as string; set => throw new NotImplementedException(); }
        public string horaireDebut { get => cboDebut.SelectedItem as string; set => throw new NotImplementedException(); }
        public string horaireFin { get => cboFin.SelectedItem as string; set => throw new NotImplementedException(); }
        public string typeRole { get => cboType.SelectedItem as string; set => throw new NotImplementedException(); }

        //events

        public event EventHandler AjouterPlanningMedecinEvent;
        public event EventHandler filtrerUserByRoleEvent;
        public event EventHandler SelectionLigneDtgvEvent;
       
        public void setPlanningBindingSource(BindingSource jourMedecinList)
        {
            dtgvPlanning.DataSource = jourMedecinList;
          

        }

        public void setBindingSource(BindingSource medecinList,BindingSource typeUserList,BindingSource HoraireListDebut, BindingSource HoraireListFin, BindingSource jourList)
        {
            dtgvUser.DataSource = medecinList;
            cboType.DataSource = typeUserList;
            cboDebut.DataSource = HoraireListDebut;
            cboFin.DataSource = HoraireListFin;
            cboJour.DataSource = jourList;
            dtgvUser.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        //Design Pattern => Singleton

        private static FormPlanningViews instance = null;
        public static FormPlanningViews showForm(Form parent)
        {
            if (parent.ActiveMdiChild != null)
            {
                parent.ActiveMdiChild.Hide();
                instance = null;
               

            }
            if (instance == null || instance.IsDisposed)
            {
                instance = new FormPlanningViews();
                instance.MdiParent = parent;
            }
            return instance;
        }

        private void FormPlanningViews_Load(object sender, EventArgs e)
        {

        }

    }
}
