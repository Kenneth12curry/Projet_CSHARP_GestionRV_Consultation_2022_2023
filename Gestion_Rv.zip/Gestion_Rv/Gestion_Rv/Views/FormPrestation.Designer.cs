﻿namespace Gestion_Rv.Views
{
    partial class FormPrestation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDate = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboPatient = new System.Windows.Forms.ComboBox();
            this.dtgvPrestation = new System.Windows.Forms.DataGridView();
            this.cboDate = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelPatient = new System.Windows.Forms.Panel();
            this.btnPatient = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPrestation)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelPatient.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnDate
            // 
            this.btnDate.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDate.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnDate.Location = new System.Drawing.Point(322, 36);
            this.btnDate.Name = "btnDate";
            this.btnDate.Size = new System.Drawing.Size(45, 21);
            this.btnDate.TabIndex = 12;
            this.btnDate.Text = "Ok";
            this.btnDate.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(41, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 11;
            this.label2.Text = "Date";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(19, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "Patient";
            // 
            // comboPatient
            // 
            this.comboPatient.FormattingEnabled = true;
            this.comboPatient.Location = new System.Drawing.Point(88, 14);
            this.comboPatient.Name = "comboPatient";
            this.comboPatient.Size = new System.Drawing.Size(250, 25);
            this.comboPatient.TabIndex = 8;
            // 
            // dtgvPrestation
            // 
            this.dtgvPrestation.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.dtgvPrestation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvPrestation.Location = new System.Drawing.Point(38, 91);
            this.dtgvPrestation.Name = "dtgvPrestation";
            this.dtgvPrestation.Size = new System.Drawing.Size(777, 344);
            this.dtgvPrestation.TabIndex = 7;
            this.dtgvPrestation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvPrestation_CellContentClick);
            // 
            // cboDate
            // 
            this.cboDate.Location = new System.Drawing.Point(100, 36);
            this.cboDate.Name = "cboDate";
            this.cboDate.Size = new System.Drawing.Size(198, 25);
            this.cboDate.TabIndex = 9;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(60)))));
            this.panel1.Controls.Add(this.panelPatient);
            this.panel1.Controls.Add(this.dtgvPrestation);
            this.panel1.Controls.Add(this.btnDate);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cboDate);
            this.panel1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(34, 95);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(859, 475);
            this.panel1.TabIndex = 16;
            // 
            // panelPatient
            // 
            this.panelPatient.Controls.Add(this.comboPatient);
            this.panelPatient.Controls.Add(this.label1);
            this.panelPatient.Controls.Add(this.btnPatient);
            this.panelPatient.Location = new System.Drawing.Point(395, 20);
            this.panelPatient.Name = "panelPatient";
            this.panelPatient.Size = new System.Drawing.Size(420, 55);
            this.panelPatient.TabIndex = 17;
            // 
            // btnPatient
            // 
            this.btnPatient.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnPatient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPatient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPatient.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnPatient.Location = new System.Drawing.Point(361, 14);
            this.btnPatient.Name = "btnPatient";
            this.btnPatient.Size = new System.Drawing.Size(45, 21);
            this.btnPatient.TabIndex = 15;
            this.btnPatient.Text = "Ok";
            this.btnPatient.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(377, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(179, 22);
            this.label3.TabIndex = 17;
            this.label3.Text = "Liste des Prestations";
            // 
            // FormPrestation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(986, 631);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormPrestation";
            this.Text = "FormPrestation";
            this.Load += new System.EventHandler(this.FormPrestation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPrestation)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelPatient.ResumeLayout(false);
            this.panelPatient.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnDate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboPatient;
        private System.Windows.Forms.DataGridView dtgvPrestation;
        private System.Windows.Forms.DateTimePicker cboDate;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnPatient;
        private System.Windows.Forms.Panel panelPatient;
    }
}