﻿namespace Gestion_Rv.Views
{
    partial class FormRendezVous
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.dtgvRendezVous = new System.Windows.Forms.DataGridView();
            this.cbodatePicker = new System.Windows.Forms.DateTimePicker();
            this.btnFiltre = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAll = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddConsultation = new System.Windows.Forms.Button();
            this.btnAddPrestation = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvRendezVous)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.BackColor = System.Drawing.Color.Red;
            this.btnAnnuler.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnnuler.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnnuler.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAnnuler.Location = new System.Drawing.Point(741, 117);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(97, 29);
            this.btnAnnuler.TabIndex = 4;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = false;
            // 
            // dtgvRendezVous
            // 
            this.dtgvRendezVous.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.dtgvRendezVous.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvRendezVous.Location = new System.Drawing.Point(20, 117);
            this.dtgvRendezVous.Name = "dtgvRendezVous";
            this.dtgvRendezVous.Size = new System.Drawing.Size(710, 346);
            this.dtgvRendezVous.TabIndex = 0;
            this.dtgvRendezVous.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvRendezVous_CellContentClick);
            // 
            // cbodatePicker
            // 
            this.cbodatePicker.Location = new System.Drawing.Point(87, 71);
            this.cbodatePicker.Name = "cbodatePicker";
            this.cbodatePicker.Size = new System.Drawing.Size(291, 25);
            this.cbodatePicker.TabIndex = 2;
            // 
            // btnFiltre
            // 
            this.btnFiltre.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnFiltre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFiltre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFiltre.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnFiltre.Location = new System.Drawing.Point(405, 71);
            this.btnFiltre.Name = "btnFiltre";
            this.btnFiltre.Size = new System.Drawing.Size(47, 22);
            this.btnFiltre.TabIndex = 6;
            this.btnFiltre.Text = "OK";
            this.btnFiltre.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(60)))));
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnAll);
            this.panel1.Controls.Add(this.dtgvRendezVous);
            this.panel1.Controls.Add(this.btnAnnuler);
            this.panel1.Controls.Add(this.btnFiltre);
            this.panel1.Controls.Add(this.cbodatePicker);
            this.panel1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(27, 140);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(861, 491);
            this.panel1.TabIndex = 7;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(28, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 19);
            this.label2.TabIndex = 8;
            this.label2.Text = "Date";
            // 
            // btnAll
            // 
            this.btnAll.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAll.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAll.Location = new System.Drawing.Point(30, 22);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(79, 22);
            this.btnAll.TabIndex = 7;
            this.btnAll.Text = "rv";
            this.btnAll.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(321, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 22);
            this.label1.TabIndex = 8;
            this.label1.Text = "Liste des Rendez-Vous";
            // 
            // btnAddConsultation
            // 
            this.btnAddConsultation.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAddConsultation.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddConsultation.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddConsultation.Location = new System.Drawing.Point(657, 90);
            this.btnAddConsultation.Name = "btnAddConsultation";
            this.btnAddConsultation.Size = new System.Drawing.Size(100, 43);
            this.btnAddConsultation.TabIndex = 9;
            this.btnAddConsultation.Text = "Nouvelle Consultation";
            this.btnAddConsultation.UseVisualStyleBackColor = false;
            // 
            // btnAddPrestation
            // 
            this.btnAddPrestation.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnAddPrestation.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddPrestation.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAddPrestation.Location = new System.Drawing.Point(794, 91);
            this.btnAddPrestation.Name = "btnAddPrestation";
            this.btnAddPrestation.Size = new System.Drawing.Size(94, 43);
            this.btnAddPrestation.TabIndex = 15;
            this.btnAddPrestation.Text = "Nouvelle Prestation";
            this.btnAddPrestation.UseVisualStyleBackColor = false;
            // 
            // FormRendezVous
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(915, 665);
            this.Controls.Add(this.btnAddPrestation);
            this.Controls.Add(this.btnAddConsultation);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormRendezVous";
            this.Text = "FomRendezVous";
            this.Load += new System.EventHandler(this.FormRendezVous_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvRendezVous)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnAnnuler;
        private System.Windows.Forms.DataGridView dtgvRendezVous;
        private System.Windows.Forms.DateTimePicker cbodatePicker;
        private System.Windows.Forms.Button btnFiltre;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAll;
        private System.Windows.Forms.Button btnAddConsultation;
        private System.Windows.Forms.Button btnAddPrestation;
    }
}