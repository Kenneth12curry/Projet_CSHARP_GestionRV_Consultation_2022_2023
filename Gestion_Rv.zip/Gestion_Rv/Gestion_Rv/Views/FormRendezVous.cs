﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public partial class FormRendezVous : Form,IRendezVousView
    {
        public FormRendezVous()
        {
            InitializeComponent();
            this.activeEventClasse();
        }

        private void activeEventClasse()
        {
            //Mapping => delegate
           
            btnAnnuler.Click += delegate { annulerRvEvent.Invoke(this, EventArgs.Empty); };
            btnFiltre.Click += delegate { filtreRvEvent.Invoke(btnFiltre, EventArgs.Empty); };
            btnAll.Click += delegate { filtreRvEvent.Invoke(btnAll, EventArgs.Empty); };

            //chargements de la vue d'ajout d'une consultation et prestation

            btnAddConsultation.Click += delegate { showNouvelleConsultationEvent.Invoke(this, EventArgs.Empty); };
            btnAddPrestation.Click += delegate { showFormNouvellePrestationEvent.Invoke(this, EventArgs.Empty); };
          

        }


        //propriétés

        public DateTime listDate { 
            get => cbodatePicker.Value; 
            set => throw new NotImplementedException(); 
        }
        public bool panelConsultation { get => btnAddConsultation.Visible; set => btnAddConsultation.Visible=value; }
        public bool panelPrestation { get => btnAddPrestation.Visible; set =>btnAddPrestation.Visible=value; }
        public bool panelConsultation1 { get => btnAddConsultation.Enabled; set => btnAddConsultation.Enabled = value; }
        public bool panelPrestation1 { get => btnAddPrestation.Enabled; set => btnAddPrestation.Enabled = value; }

        //implémentation des events => évènements

        public event EventHandler annulerRvEvent;
        public event EventHandler filtreRvEvent;
        public event EventHandler showFormNouvellePrestationEvent;
        public event EventHandler showNouvelleConsultationEvent;
      



        //BidingSource
        public void setRendezVousBindingSource(BindingSource rvList)
        {
            //BidingSource
            dtgvRendezVous.DataSource = rvList ;
        }

        
        //Design Pattern => Singleton

        private static FormRendezVous instance = null;

        public static  FormRendezVous showForm(Form parent)
        {
            if (parent.ActiveMdiChild != null)
            {
                parent.ActiveMdiChild.Hide();
                instance = null;
                
            }
            if(instance == null || instance.IsDisposed)
            {
                instance = new FormRendezVous();
                instance.MdiParent = parent;
            }
            return instance;
        }

        private void FormRendezVous_Load(object sender, EventArgs e)
        {

        }

        private void dtgvRendezVous_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
