﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Views
{
    public interface IConnexionView
    {
        //Propriétés => Tous les champs sur l'interface
        string Login { get; set; }
        string Password { get; set;}

        //Propriétés pour gérer les erreurs sur la page de connexion
        string Message { get; set; }
        bool IsLoggedIn { get; set; }

        //event => événements
        event EventHandler ConnexionEvent;

        //méthode propre à c# pour ne plus afficher la page après la connexion
        void Hide();
        void Show();
        
    }
}
