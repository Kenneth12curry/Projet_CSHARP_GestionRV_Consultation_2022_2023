﻿using Gestion_Rv.Dto;
using System;
using System.Collections.Generic;
using System.Drawing.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public interface IConsultationView
    {
        //Propriétés => tous les champs sur l'interface
        bool PanelPatient { get; set; }
        PatientDto listPatient { get; set; }
        DateTime Date { get; set; }

        //events => évènements
      
        event EventHandler showFormDetailsConsultationsEvent;
        event EventHandler showFiltreConsultationEvent;

        //Méthodes => BidingSource
        void setConsultationBidingSource(BindingSource consultationList, BindingSource patientList);

        //méthode propre à c# pour afficher une vue
        void Show();
    }
}
