﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public interface IConsultationsAndPrestationsPatientView
    {
        //Propriétés=> tous les champs de l'interface
        string nomPatient { get; set; }
        string prenomPatient { get; set; }
        string codePatient { get; set; }

        //events => évènements
        event EventHandler showFormEvent;
        event EventHandler closeFenenetreEvent;
        //Méthodes
        void setConsultationsAndPrestationBidingSource(BindingSource consultationsPrestationsList);
        void Show();
        void Dispose();
    }
}
