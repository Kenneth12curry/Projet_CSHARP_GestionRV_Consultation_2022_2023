﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Views
{
    public interface ICreationPatientView
    {
        //Propriétés
        string nomPatient { get; set; }
        string prenomPatient { get; set; }
        string emailPatient { get; set; }
        string telPatient { get; set; }
        //events
        event EventHandler ajouterPatientEvent;
        void Show();

    }
}
