﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public interface IDetailsConsultationView
    {
        //Propriétés => Tous les champs sur l'interface
        string nomPatient { get; set; }
        string prenomPatient { get; set; }
        string codePatient { get; set; }
        string date { get; set; }
        string temperature { get; set; }
        string tension { get; set; }
        string poids { get; set; }
        string motif { get; set; }
        string nomMedecin { get; set; }
        string prenomMedecin { get; set; }
        string typeMedecin { get; set; }
       

        //events => Evenèments
        event EventHandler showMedicament;
        event EventHandler SelectionLigneDtgvEvent;

        //Méthodes => A chaque fois qu'il un champ qui doit être chargé dans la vue
        void setBidingSource(BindingSource ordonnanceList);
        void setMedicamentBidingSource(BindingSource medicamentList);
        void Show();
    }
}
