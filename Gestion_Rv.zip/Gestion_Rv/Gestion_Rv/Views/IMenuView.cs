﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gestion_Rv.Views
{
    public interface IMenuView
    {
        //Propriétés => Tous les chapms sur l'interface
        string userLabel { get; set; }
        User userConnect { get; set; }

        //Propriétés pour les boutons du menu
        bool consultation { get; set; }
        bool prestation { get; set; }
        bool rendezVous { get; set; }
        bool patient { get; set; }
        bool planning { get; set; }




        //Event => Tous les évènements sur l'interface
        event EventHandler showFormEvent;
        //event EventHandler closeFenetreEvent;
      

        //méthode propre à c# pour afficher la page menu
        void Show();

        void Hide();
        //methode pour supprimer l'intance de la page
        void Dispose();
    }
}
