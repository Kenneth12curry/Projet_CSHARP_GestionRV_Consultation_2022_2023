﻿using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public interface INouveauRvView
    {
        //Propriétés => tous les champs sur l'interface
        string nomPatient { get; set; }
        string prenomPatient { get; set; }
        string codePatient { get; set; }
        string heure { get; set; }
        DateTime date { get; set; }   
        string jour { get; set; }
        string typeRdv { get; set; }
        string emailPatient { get; set; }
        string emailPatient1 { get; set; }
        string objectMessage { get; set; }
        string Message { get; set; }
        bool mail { get; set; }


        //events
       
        event EventHandler SelectionLigneDtgvEvent;
        event EventHandler creerRdvEvent;
        event EventHandler searchEvent;
        event EventHandler sendMailEvent;


        //méthodes => A chaque fois qu'il y'a un champ qui doit être chargé dans la vue
        void setList(BindingSource heureList,BindingSource JourList,BindingSource rdvList);
        void setBindingSource(BindingSource userList);
        void setBidingSource(BindingSource planningListUser);

        //méthode propre à c# pour afficher la vue
        void Show();


    }
}
