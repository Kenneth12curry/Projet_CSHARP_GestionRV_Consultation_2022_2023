﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public interface INouvelleConsultationView
    {
        //Propriétés => tous les champs sur l'interface
        bool checkedRadio { get; set; }
        bool checkedRadio1 { get; set; }
        bool groupBoxOrdonnance { get; set; }
        bool panelConsultation { get; set; }
        bool panelMed { get; set; }
        bool panelOrdonnance { get; set; }
        bool libelleOrdonnance { get; set; }
        string Date { get; set; }
        string Medecin { get; set; }
        string Patient { get; set; }
        string saisieTemperature { get; set; }
        string saisieTension { get; set; }
        string saisiePoids { get; set; }
        string saisieMotif { get; set; }

        string saisieNumeroOrdonnance { get; set; }
        string saisieCode { get; set; }
        string saisieNom { get; set; }
        string saisiePosologie { get; set; }

        //events = évènements
        event EventHandler enregistrerEvent;
        event EventHandler ajoutMedEvent;
        event EventHandler radioButtonEvent;
        event EventHandler creerOrdonnanceEvent;
       

        void Show();

    }
}
