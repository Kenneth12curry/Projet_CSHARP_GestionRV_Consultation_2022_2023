﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
   public interface INouvellePrestationView
    {
        //propriétés tous les champs sur l'interface
        bool prestation { get; set; }
        string Date { get; set; }
        string typePrestation { get; set; }
        string Patient { get; set; }

        //events => évènements
        event EventHandler enregistrerAndannulerPrestationEvent;

        //Biding Source
        void setBidingSource(BindingSource typePlist);
        void Show();
    }
}
