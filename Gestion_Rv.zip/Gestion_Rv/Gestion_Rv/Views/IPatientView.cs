﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public interface IPatientView
    {
        //Propriétés => tous les champs sur l'interface
        bool patient { get; set; }
        bool DossierMedical { get; set; }
        bool planifierRdv { get; set; }
        string nomRecherche { get; set; }

        //events => évènements

        event EventHandler rechercherPatientEvent;
        event EventHandler showPatientEvent;
        event EventHandler loadViewConsultationsAndPrestationsUnPatient;
        event EventHandler nouveauRvEvent;
       
        //méthodes
        void setPatientlist(BindingSource patientList);

        void Show();
    }
}
