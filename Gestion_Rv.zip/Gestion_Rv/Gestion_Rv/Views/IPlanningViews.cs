﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public interface IPlanningViews
    {
        //Propriétés tous les champs su l'interface
        string jourSemaine { get; set; }
        string horaireDebut { get; set; }
        string horaireFin { get; set; }
        string typeRole { get; set; }

        //evenst
        event EventHandler AjouterPlanningMedecinEvent;
        event EventHandler filtrerUserByRoleEvent;
        event EventHandler SelectionLigneDtgvEvent;

        //Méthodes
        void setBindingSource(BindingSource medecinList,BindingSource typeUserList,BindingSource HoraireListDebut, BindingSource HoraireListFin, BindingSource jourList);
        void setPlanningBindingSource(BindingSource jourMedecinList);
        void Show();
    }
}
