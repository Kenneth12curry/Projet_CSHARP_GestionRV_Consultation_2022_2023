﻿using Gestion_Rv.Dto;
using Gestion_Rv.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public interface IPrestationView
    {
        //Propriétés=>Tous les champs sur l'interface
        bool PanelPatient { get; set; }
        PatientDto listPatient { get; set; }
        DateTime Date { get; set; }

        //events => évènements
        event EventHandler showFiltreEvent;

        //Méthodes => BidingSource
        void setPrestationBidingSource(BindingSource prestationList,BindingSource patientList);

        //méthode propre à c# pour afficher une vue
        void Show();
    }
}
