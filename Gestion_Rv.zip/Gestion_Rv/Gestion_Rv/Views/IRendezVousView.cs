﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gestion_Rv.Views
{
    public interface IRendezVousView
    {
        //Propriétés => Tous les champs sur l'interface

        bool panelConsultation  { get; set; }
        bool panelPrestation { get; set; }

        bool panelConsultation1 { get; set; }
        bool panelPrestation1 { get; set; }
        DateTime listDate { get; set; }
      
        //events =>évènements

        //event EventHandler prestationRvEvent;
        event EventHandler filtreRvEvent;
        event EventHandler annulerRvEvent;
        event EventHandler showFormNouvellePrestationEvent;
        event EventHandler showNouvelleConsultationEvent;
      


        //mtehodes => A chaque fois qu'il y'a un champ qui doit être chargé dans la vue
        void setRendezVousBindingSource(BindingSource rvList);

        //méthode propre à c# pour afficher une vue
        void Show();
    }
}
